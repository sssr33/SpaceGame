#include <windows.h>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <math.h>

//������ ��������� �������������� �� �������
#define AI_BOTTOM 0
#define AI_TOP 1
#define AI_LEFT 2
#define AI_RIGHT 3
//������ ��������� �������������� �� �������

/*struct bullet{
        static POINT point;
        static int body;
        bullet *next;
};
class Bullets{
        bullet * top;

};*/
//class AI;

POINT mainRect[2] = {{100,50},{900,650}};


class ENEMY {
   //     friend class AI;
        int a;
        int b;
        POINT model[2];
        bool status;
public:
        ENEMY() { a = 20; b = 20; status = 1; }
        void draw_enemy(HDC hdc);
        void set_model_pos(unsigned x, unsigned y);
        void anim_test(unsigned x, unsigned lim1 ,unsigned lim2);
        POINT get_Xt_Xb_pos() const;
};

POINT ENEMY :: get_Xt_Xb_pos() const {
POINT pos;
pos.x = model[0].x;
pos.y = model[1].x;

return pos;
}

void ENEMY :: anim_test(unsigned x, unsigned lim1 ,unsigned lim2){
        if((x > (model[0].x + model[1].x) / 2) && (model[0].x > lim1) && (model[1].x < lim2)){ model[0].x += 2; model[1].x += 2; }
        else if((x < (model[0].x + model[1].x) / 2) && (model[0].x > lim1) && (model[1].x < lim2)) { model[0].x -= 2; model[1].x -= 2; }
        else if((x < (model[0].x + model[1].x) / 2) && (model[0].x > lim1) && (model[1].x <= lim2+6)) { model[0].x -= 2; model[1].x -= 2; }
        else if((x > (model[0].x + model[1].x) / 2) && (model[0].x >= lim1-6) && (model[1].x < lim2)) { model[0].x += 2; model[1].x += 2; }
}

void ENEMY :: set_model_pos(unsigned x, unsigned y) {
        model[0].x = x - a;
        model[0].y = y - b;
        model[1].x = x + a;
        model[1].y = y + b;
}

void ENEMY :: draw_enemy(HDC hdc){
        if(status) {
        Rectangle(hdc,model[0].x,model[0].y,model[1].x,model[1].y);
        SetPixel(hdc,(model[0].x + model[1].x) / 2, (model[0].y + model[1].y) / 2,RGB(255,0,0));
        }
}

class AI{
        unsigned sectors_num;
        unsigned sector_lenght;
        unsigned sector_middle;
        RECT *sectors;
        unsigned mode;
        unsigned enemy_num;
        POINT *respawn_point;
        ENEMY *en_ship;

        void division(unsigned max_coord,unsigned min_coord, unsigned top, unsigned bottom);
        void set_respawn_points();
        unsigned set_sector_middle(unsigned a, unsigned b);
public:
        AI(unsigned sect, unsigned m);
        void test(HDC);
        void enemy_control(unsigned posX);
};

void AI :: enemy_control(unsigned posX) {
POINT pos;
unsigned start = 0, end = 3;

        for(int i = 0; i < sectors_num, end <= enemy_num; i++) {
        for(int start = 0; start < end; start++) {
                //pos = en_ship[start].get_Xt_Xb_pos();
                /*if((pos.x > sectors[i].left) && (pos.y < sectors[i].right))*/
                en_ship[start].anim_test(posX,sectors[i].left,sectors[i].right);
        }
        start = end;
        end += 3;
        }
}

AI :: AI(unsigned sect, unsigned m) {
        enemy_num = 9;
        sectors_num = sect;
        en_ship = new ENEMY[enemy_num];
        sectors = new RECT[sectors_num];
        respawn_point = new POINT[enemy_num];
                switch(m) {
                case AI_BOTTOM:

                                division(mainRect[1].x,mainRect[0].x, mainRect[1].y,(mainRect[1].y - mainRect[0].y) - ((mainRect[1].y - mainRect[0].y)/3));//height = 450
                                sector_middle = set_sector_middle(sectors[sectors_num-1].left,sectors[sectors_num-1].right);
                                set_respawn_points();
                                break;
                case AI_TOP:
                                division(mainRect[1].x,mainRect[0].x, mainRect[0].y,(mainRect[1].y - mainRect[0].y)/2); //height = 150
                                sector_middle = set_sector_middle(sectors[0].left,sectors[0].right);
                                set_respawn_points();
                                break;
                case AI_LEFT:
                                division(mainRect[1].y,mainRect[0].y, mainRect[0].x,(mainRect[1].x - mainRect[0].x)/3); //height = 200
                                sector_middle = set_sector_middle(sectors[sectors_num-1].right,sectors[sectors_num-1].left);
                                set_respawn_points();
                                break;
                case AI_RIGHT:
                                division(mainRect[1].y,mainRect[0].y, mainRect[1].x,(mainRect[1].x - mainRect[0].x) - ((mainRect[1].x - mainRect[0].x)/3)); //height = 600
                                sector_middle = set_sector_middle(sectors[sectors_num-1].right,sectors[sectors_num-1].left);
                                set_respawn_points();
                                break;
                default:
                                division(mainRect[1].x,mainRect[0].x, mainRect[0].y,(mainRect[1].y - mainRect[0].y)/3); //height = 150
                                sector_middle = set_sector_middle(sectors[sectors_num-1].left,sectors[sectors_num-1].right);
                                set_respawn_points();
                                break;
                }
}

void AI :: division(unsigned max_coord,unsigned min_coord, unsigned top, unsigned bottom) {
        sector_lenght = (max_coord - min_coord) / sectors_num;
        unsigned temp_lenght = sector_lenght;
        unsigned temp_lenght2 = 0;
        for(int i = 0; i < sectors_num; i++) {
        sectors[i].left = max_coord - temp_lenght;
        sectors[i].top = top;
        sectors[i].right = max_coord - temp_lenght2;
        sectors[i].bottom = bottom;
        temp_lenght += sector_lenght;
        temp_lenght2 += sector_lenght;
        }
}

void AI :: set_respawn_points(){
unsigned start = 0, end = 3;
//unsigned offsetY = 30;
unsigned offsetY = (sectors[0].bottom - sectors[0].top)/4;
unsigned offsetX = sector_middle;
        for(int i = 0; i < sectors_num, end <= enemy_num; i++,offsetX -= sector_lenght){
                for(int j = start; j < end; j++, offsetY += (sectors[0].bottom - sectors[0].top)/4){
                respawn_point[j].x = offsetX;
                respawn_point[j].y = sectors[i].bottom - offsetY;
                en_ship[j].set_model_pos(respawn_point[j].x, respawn_point[j].y);
                }
        offsetY = (sectors[0].bottom - sectors[0].top)/4;
        start = end;
        end += 3;
        }
}

unsigned AI :: set_sector_middle(unsigned a, unsigned b) {
return (a + b) / 2;
}

void AI :: test(HDC hdc) {
        for(int i = 0; i < enemy_num; i++) en_ship[i].draw_enemy(hdc); //SetPixel(hdc,respawn_point[i].x,respawn_point[i].y,RGB(255,0,0));
        for(int i = 0; i < 3; i++){
        MoveToEx(hdc,sectors[i].left,sectors[i].top,NULL);
        LineTo(hdc,sectors[i].left,sectors[i].bottom);
        }
}

class STATS{
        HPEN Pen;
        HBRUSH Brush;
        RECT rectGraph;
        void DrawShip(HDC hdc);
public:
        STATS();
        void DrawGraphStats(HDC hdc);
};

STATS :: STATS() {
        Pen = CreatePen(PS_SOLID,3,RGB(0,0,100));
        Brush = CreateSolidBrush(RGB(0,0,0));
        rectGraph.left = mainRect[0].x/8;
        rectGraph.top =  mainRect[1].y/2;
        rectGraph.right = mainRect[0].x-1;
        rectGraph.bottom = mainRect[1].y - 200;
}

void STATS :: DrawGraphStats(HDC hdc){
        SelectObject(hdc,Pen);
        SelectObject(hdc,Brush);
        Rectangle(hdc,rectGraph.left,rectGraph.top,rectGraph.right,rectGraph.bottom);
        DrawShip(hdc);
        DeleteObject(Pen);
        DeleteObject(Brush);
}

void STATS :: DrawShip(HDC hdc) {
        Pen = CreatePen(PS_SOLID,3,RGB(0,50,0));//100
        Brush = CreateSolidBrush(RGB(0,100,0));
        SelectObject(hdc,Brush);
        SelectObject(hdc,Pen);

        
        Ellipse(hdc,rectGraph.left + 30,rectGraph.top + 30,rectGraph.right - 30,rectGraph.bottom - 30);
        Ellipse(hdc,rectGraph.left + 40,rectGraph.top + 45,rectGraph.right - 40,rectGraph.bottom - 45);

        Brush = CreateSolidBrush(RGB(100,0,0));
        SelectObject(hdc,Brush);
        Rectangle(hdc,rectGraph.left+20,rectGraph.top+85,rectGraph.right-20,rectGraph.bottom - 25);
        Rectangle(hdc,rectGraph.left+10,rectGraph.top+50,rectGraph.right-55,rectGraph.bottom - 55);
        Rectangle(hdc,rectGraph.left+55,rectGraph.top+50,rectGraph.right-10,rectGraph.bottom - 55);

        Brush = CreateSolidBrush(RGB(100,100,0));
        SelectObject(hdc,Brush);
        Rectangle(hdc,rectGraph.left + 40,rectGraph.top + 20,rectGraph.right - 40,rectGraph.top +30);
        Rectangle(hdc,rectGraph.left + 20,rectGraph.top + 40,rectGraph.right - 60,rectGraph.top +50);
        Rectangle(hdc,rectGraph.left + 60,rectGraph.top + 40,rectGraph.right - 20,rectGraph.top +50);
        }

class STARS{
        int starsNum;
        int starSpeed;
        POINT *mas;
public:
        STARS(unsigned s, unsigned num);
        void starsSet();
        void starsDraw(HDC hdc) const;
};

STARS :: STARS(unsigned s, unsigned num) {
  starSpeed = s;
  starsNum = num;
  mas = new POINT[starsNum];

  srand(time(NULL));
  for(int i = 0; i < starsNum; i++){
        mas[i].x = (rand()%800) + 100;
        mas[i].y = ((600/starsNum)*i)+50;
        }
}

void STARS :: starsSet() {
for(int i = 0; i < starsNum; i++){
        mas[i].y += starSpeed;
        if(mas[i].y > mainRect[1].y){
                mas[i].y = 50;
                mas[i].x = (rand()%800) + 100;
        }
}
}

void STARS :: starsDraw(HDC hdc) const{
for(int i = 0; i < starsNum; i++) SetPixel(hdc,mas[i].x,mas[i].y,RGB(255,255,255));
}

STARS star(5,15);
STATS stat;
AI control(3,AI_TOP);

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
 HWND hWndMain;
 HWND hButton1;
 char szClassName[] = "MainWndClass";
 MSG msg;
 WNDCLASSEX wc;

 wc.cbSize = sizeof(wc);
 wc.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS | CS_OWNDC;
 wc.lpfnWndProc = WndProc;
 wc.cbClsExtra = 0;
 wc.cbWndExtra = 0;
 wc.hInstance = hInstance;
 wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
 wc.hCursor = LoadCursor(NULL, IDC_ARROW);
 wc.hbrBackground = CreatePatternBrush(LoadImage(NULL,"back.bmp",IMAGE_BITMAP,0,0,LR_LOADFROMFILE));
 wc.lpszMenuName = NULL;
 wc.lpszClassName = szClassName;
 wc.hIconSm = LoadIcon(NULL, IDI_WARNING);

 if(!RegisterClassEx(&wc)) {
   MessageBox(NULL, "Cannot register class", "Error", MB_OK);
   return 0;
 }

 hWndMain = CreateWindow(szClassName, "Game. pre-alpha buil.v014", WS_MAXIMIZE | WS_CAPTION | WS_VISIBLE | WS_TABSTOP, CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, (HWND)NULL, (HMENU)NULL, (HINSTANCE) hInstance, NULL);
 //hButton1 = CreateWindow("BUTTON", "exit", WS_CHILD, 0, 0, 100, 20, hWndMain, (HMENU)NULL, (HINSTANCE) hInstance, NULL);
 if(!hWndMain) {
   MessageBox(NULL, "Cannot create main window", "Error", MB_OK);
   return 0;
 }

 ShowWindow(hWndMain, SW_MAXIMIZE);
 //ShowWindow(hButton1, nCmdShow);
 //UpdateWindow(hWndMain);


 while(GetMessage(&msg, NULL, 0, 0)) {
   TranslateMessage(&msg);
   DispatchMessage(&msg);
 }

 return msg.wParam;

}

LRESULT CALLBACK WndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {

HDC hdc;
PAINTSTRUCT ps;
RECT rect;
RECT MyButton;

//
MyButton.left = 5;
MyButton.top = 50;
MyButton.right = 90;
MyButton.bottom = 70;
//

//rect update
RECT updateRect;
updateRect.left = mainRect[0].x;
updateRect.top = mainRect[0].y;
updateRect.right = mainRect[1].x;
updateRect.bottom = mainRect[1].y;
//rect update

//rect color
static HPEN mainRectLine, temp;
static HBRUSH mainRectBack , old;
LOGBRUSH logMRL;
logMRL.lbStyle = BS_SOLID;
logMRL.lbColor = RGB(0,0,100);
//rect color

//ship
static POINT ship;
static POINT bullet;
char coord[100];
//ship


switch(uMsg) {
case WM_CREATE:
                srand(time(NULL));
                hdc = GetDC(hwnd);
                SetBkMode(hdc,TRANSPARENT);
                SetTextColor(hdc,RGB(255,255,255));
                SetTimer(hwnd,1,40,NULL);
                mainRectBack = CreateSolidBrush(RGB(0,0,0));
                mainRectLine = ExtCreatePen(PS_GEOMETRIC | PS_SOLID | PS_ENDCAP_SQUARE,3,&logMRL,NULL,NULL);
                temp = CreatePen(PS_SOLID,3,RGB(255,255,255));
                break;
case WM_KEYDOWN:
                switch((int) wParam){
                                case VK_SPACE:
                                                KillTimer(hwnd,1);
                                                DeleteObject(temp);
                                                DeleteObject(mainRectLine);
                                                DeleteObject(mainRectBack);
                                                DestroyWindow(hwnd);
                                                PostQuitMessage(0);
                                                break;
                }
                break;
case WM_TIMER :
                star.starsSet();
                control.enemy_control(ship.x);
                if(bullet.y > 90)bullet.y -= 45;
                //if(bullet.y < 150 && bullet.y > 50 && bullet.x > eship.x-25 && bullet.x < eship.x+25)  status = 0;
                InvalidateRect(hwnd,&updateRect,0);
                break;
case WM_MOUSEMOVE:
                ship.x = LOWORD(lParam);
                ship.y = HIWORD(lParam);
                break;
case WM_LBUTTONDOWN:
                bullet.x = ship.x;
                bullet.y = 500;
                hdc = GetDC(hwnd);
                MoveToEx(hdc,ship.x,500,NULL);
                AngleArc(hdc,ship.x,490,10,360,360);
                if((LOWORD(lParam) > MyButton.left) && (LOWORD(lParam) < MyButton.right) && (HIWORD(lParam) > MyButton.top) && (HIWORD(lParam) < MyButton.bottom)) DestroyWindow(hwnd);

                break;
case WM_PAINT:
                hdc = BeginPaint(hwnd,&ps);
                //SetBkMode(hdc,TRANSPARENT);
                GetClientRect(hwnd,&rect);

                //main RECT
                SelectObject(hdc,mainRectLine);
                old = SelectObject(hdc,mainRectBack);
                Rectangle(hdc,mainRect[0].x,mainRect[0].y,mainRect[1].x,mainRect[1].y);
                //main RECT

                star.starsDraw(hdc);

                //ship navigation
                SelectObject(hdc,temp);
                if(ship.x-25 > mainRect[0].x + 3 && ship.x+25 < mainRect[1].x - 3)Rectangle(hdc,ship.x-25,500,ship.x+25,550);
                else if(ship.x-25 < mainRect[0].x + 3) Rectangle(hdc,100,500,150,550);
                else if(ship.x+25 > mainRect[1].x - 3) Rectangle(hdc,850,500,900,550);
                //ship navigation

                //bullet
                SelectObject(hdc,old);
                SetPixel(hdc,bullet.x,bullet.y,RGB(255,0,0));
                //bullet

                //sys inf
                sprintf(coord,"sys inf:       \nX = %d  Y = %d",bullet.x,bullet.y);
                DrawText(hdc,coord,-1,&updateRect,DT_RIGHT);
                //sys inf

                stat.DrawGraphStats(hdc);
                control.test(hdc);

                SelectObject(hdc,mainRectBack);
                SelectObject(hdc,mainRectLine);
                RoundRect(hdc,MyButton.left,MyButton.top,MyButton.right,MyButton.bottom,8,8);
                TextOut(hdc,33,50,"exit",5);

                EndPaint(hwnd,&ps);
                break;
case WM_CLOSE:
                KillTimer(hwnd,1);
                DeleteObject(temp);
                DeleteObject(mainRectLine);
                DeleteObject(mainRectBack);
                DestroyWindow(hwnd);
                break;
case WM_DESTROY:
                PostQuitMessage(0);
                break;
default:
                return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

return 0;
}


 