#include <windows.h>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <math.h>


#define BUTTON1 1

POINT mainRect[2] = {{100,50},{900,650}};
class Tremor{
public:
        POINT point;
        POINT vector;
        int value;

        Tremor(){
                point.y=0;
                point.x=0;
                vector.x=0;
                vector.y=1;
                value=0;
        }
        void AddTremor(int val){
                value+=val;
        }
        void DecayTremor(){
                point.x=value*vector.x;
                point.y=value*vector.y;
                vector.x*=-1;
                vector.y*=-1;
                if(value>0)
                value--;
        }
};
Tremor tremor;

struct Blast{
        POINT point;
        int step;
        int type;
        Blast *next;
        Blast *parent;
};
class Blasts{
        Blast *head;
public:
        int kolBlasts;
        Blasts(){
                head=0;
                kolBlasts=0;
        }
        Blast* Next(Blast *p){
                return p->next;
        }
        void AddBlast(int x,int y,int type){
                kolBlasts++;
                if(head==0){
                        head=new Blast();
                        head->next=0;
                }
                else
                {
                        Blast *var=new Blast();
                        var->next=head;
                        head->parent=var;
                        head=var;
                }
                head->point.x=x;
                head->point.y=y;
                head->type=type;
                head->step=1;
                head->parent=0;
        }
        Blast* DeleteBlast(Blast *p){
                if(p==0)
                        return 0;
                if(head==p){
                        if(p->next==0){
                                head=0;
                        }
                        else
                        {
                                head=p->next;
                                (p->next)->parent=0;
                        }
                }
                else
                {
                        if(p->next==0){
                                (p->parent)->next=0;
                        }
                        else
                        {
                                (p->parent)->next=p->next;
                                (p->next)->parent=p->parent;
                        }
                }
                Blast *temp=p->next;
                delete p;
                kolBlasts--;
                return temp;
        }
        void DrawAllBlasts(HDC hdc){
                if(!head)
                        return;
                HPEN Pen;
                HBRUSH Brush;
                Blast *p=head;
                while(p){
                        switch(p->type){
                                case 1:
                                        Pen = CreatePen(PS_SOLID,1,RGB((150-(p->step*8)),0,0));
                                        Brush = CreateSolidBrush(RGB(255,(255-(p->step*15)),(255-(p->step*20))));
                                        SelectObject(hdc,Brush);
                                        SelectObject(hdc,Pen);
                                        Ellipse(hdc, p->point.x-p->step+tremor.point.x, p->point.y-p->step+tremor.point.y, p->point.x+p->step+tremor.point.x, p->point.y+p->step+tremor.point.y);
                                        if(p->step>=10)
                                                p->type=0;
                                        DeleteObject(Brush);
                                        DeleteObject(Pen);
                                        break;
                                case 2:

                                        Pen = CreatePen(PS_SOLID,1,RGB((150-(p->step*7)),0,0));
                                        Brush = CreateSolidBrush(RGB(255,(255-(p->step*10)),(255-(p->step*15))));
                                        SelectObject(hdc,Brush);
                                        SelectObject(hdc,Pen);
                                        Ellipse(hdc, p->point.x-(p->step*2)+tremor.point.x, p->point.y-(p->step*2)+tremor.point.y, p->point.x+(p->step*2)+tremor.point.x, p->point.y+(p->step*2)+tremor.point.y);
                                        if(p->step>=15)
                                                p->type=0;
                                        DeleteObject(Brush);
                                        DeleteObject(Pen);
                                        break;
                        }
                        if(p->type==0)
                                p=DeleteBlast(p);
                        else
                                p=Next(p);
                }
        }
        void DecayBlasts(){
                Blast *p=head;
                while(p){
                        p->step++;
                        p=Next(p);
                }
        }
};
Blasts blasts;

struct Bullet{
        POINT point;
        double vector;
        int body;
        int power;
        int speed;
        Bullet *next;
        Bullet *parent;
};
class Bullets{
        Bullet *head;
        int kolBullets;
public:
        Bullets(){
                head=0;
                kolBullets=0;
        }
        Bullet* Next(Bullet *p){
                return p->next;
        }
        void AddBullet(int x,int y,double vector,int speed,int body,int power){
                kolBullets++;
                if(head==0){
                        head=new Bullet();
                        head->next=0;
                }
                else
                {
                        Bullet *var=new Bullet();
                        var->next=head;
                        head->parent=var;
                        head=var;
                }
                head->point.x=x;
                head->point.y=y;
                head->vector=vector;
                head->body=body;
                head->power=power;
                head->speed=speed;
                head->parent=0;
        }
        Bullet* DeleteBullet(Bullet *p){
                if(p==0)
                        return 0;
                if(head==p){
                        if(p->next==0){
                                head=0;
                        }
                        else
                        {
                                head=p->next;
                                (p->next)->parent=0;
                        }
                }
                else
                {
                        if(p->next==0){
                                (p->parent)->next=0;
                        }
                        else
                        {
                                (p->parent)->next=p->next;
                                (p->next)->parent=p->parent;
                        }
                }
                Bullet *temp=p->next;
                delete p;
                kolBullets--;
                return temp;
        }
        void DrawAllBullets(HDC hdc){
                if(!head)
                        return;
                HPEN Pen;
                HBRUSH Brush;
                Bullet *p=head;
                while(p){
                        switch(p->body){
                                case 0:
                                        SetPixel(hdc,p->point.x,p->point.y,RGB(255,255,255));
                                        break;
                                case 1:
                                        Pen = CreatePen(PS_SOLID,2,RGB(255,255,255));
                                        SelectObject(hdc,Pen);
                                        MoveToEx(hdc,p->point.x+tremor.point.x,p->point.y+tremor.point.y,0);
                                        LineTo(hdc,p->point.x-(int)(cos(p->vector)*10)+tremor.point.x,p->point.y+(int)(sin(p->vector)*10)+tremor.point.y);
                                        DeleteObject(Pen);
                                        break;
                                case 2:
                                        Pen = CreatePen(PS_SOLID,3,RGB(255,255,255));
                                        SelectObject(hdc,Pen);
                                        MoveToEx(hdc,p->point.x+tremor.point.x,p->point.y+tremor.point.y,0);
                                        LineTo(hdc,p->point.x-(int)(cos(p->vector)*10)+tremor.point.x,p->point.y+(int)(sin(p->vector)*10)+tremor.point.y);
                                        DeleteObject(Pen);
                                        break;
                                case 3:
                                        Pen = CreatePen(PS_SOLID,3,RGB(100,255,100));
                                        SelectObject(hdc,Pen);
                                        MoveToEx(hdc,p->point.x+tremor.point.x,p->point.y+tremor.point.y,0);
                                        LineTo(hdc,p->point.x-(int)(cos(p->vector)*10)+tremor.point.x,p->point.y+(int)(sin(p->vector)*10)+tremor.point.y);
                                        DeleteObject(Pen);
                                        break;
                                case 4:
                                        Pen = CreatePen(PS_SOLID,3,RGB(255,100,100));
                                        SelectObject(hdc,Pen);
                                        MoveToEx(hdc,p->point.x+tremor.point.x,p->point.y+tremor.point.y,0);
                                        LineTo(hdc,p->point.x-(int)(cos(p->vector)*10)+tremor.point.x,p->point.y+(int)(sin(p->vector)*10)+tremor.point.y);
                                        DeleteObject(Pen);
                                        break;
                        }
                        p=Next(p);
                }
        }
        void BulletsFly(){
                Bullet *p=head;
                while(p){
                        p->point.x+=(int)cos(p->vector)*(p->speed);
                        p->point.y-=(int)sin(p->vector)*(p->speed);
                        if(p->point.x>mainRect[1].x||p->point.x<mainRect[0].x||p->point.y>mainRect[1].y||p->point.y<mainRect[0].y){
                                p=DeleteBullet(p);
                        }
                        else{
                                p=Next(p);
                        }
                }
        }
        int HitBullets(int x1,int y1,int x2,int y2){
                Bullet *p=head;
                int sumDamage=0;
                while(p){
                        if(p->point.x>x1&&p->point.y>y1&&p->point.x<x2&&p->point.y<y2){
                                sumDamage+=p->power;
                                blasts.AddBlast(p->point.x,p->point.y,1);
                                p=DeleteBullet(p);

                        }
                        else{
                                p=Next(p);
                        }
                }
                return sumDamage;
        }
};
Bullets bullets;
Bullets shipBullets;




struct Enemy{
        POINT point1;
        int body;
        int halse;
        int bullet;
        int power;
        int speed;
        double move;
        Enemy *next;
        Enemy *parent;
};
class Enemys{
        Enemy *head;
public:
        int kolEnemys;
        Enemys(){
                head=0;
                kolEnemys=0;
        }
        Enemy* Next(Enemy *p){
                return (p->next);
        }
        void AddEnemys(int x,int y,int body,int halse,double movenemy,int bullet,int power,int speed){
                kolEnemys++;
                if(head==0){
                        head=new Enemy();
                        head->next=0;
                }
                else
                {
                        Enemy *var=new Enemy();
                        var->next=head;
                        head->parent=var;
                        head=var;
                }
                head->move=movenemy;
                head->point1.x=x+(int)(sin(head->move)*10.);
                head->point1.y=y;
                head->body=body;
                head->halse=halse;
                head->bullet=bullet;
                head->power=power;
                head->speed=speed;
                head->parent=0;
        }
        void AddAllEnemys(int kol,int body,int halse,int bullet, int power,int speed){
                int rowsize=(mainRect[1].x-mainRect[0].x)/(kol+1);
                int pol=rowsize;
                srand(time(NULL));
                for(int i=0;i<kol;i++){
                        AddEnemys(pol+mainRect[0].x,mainRect[0].y+50,body,halse,rand(),bullet,power,speed);
                        pol+=rowsize;
                }
                pol=rowsize;
                for(int i=0;i<kol;i++){
                        AddEnemys(pol+mainRect[0].x,mainRect[0].y+125,body,halse,rand(),bullet,power,speed);
                        pol+=rowsize;
                }
                pol=rowsize;
                for(int i=0;i<kol;i++){
                        AddEnemys(pol+mainRect[0].x,mainRect[0].y+200,body,halse,rand(),bullet,power,speed);
                        pol+=rowsize;
                }
        }

        Enemys(int a,int b,int c,int d,int e,int f){
                head=0;
                kolEnemys=0;
                AddAllEnemys(a,b,c,d,e,f);
        }
        void DrawAllEnemys(HDC hdc){
                if(!head)
                        return;
                HPEN Pen;
                HBRUSH Brush;
                Enemy *p=head;
                while(p){
                switch(p->body){
                case 0:
                        Pen = CreatePen(PS_SOLID,1,RGB(100,100,100));
                        Brush = CreateSolidBrush(RGB(255,255,255));
                        SelectObject(hdc,Brush);
                        SelectObject(hdc,Pen);
                        Rectangle(hdc, p->point1.x-25+tremor.point.x, p->point1.y-25+tremor.point.y, p->point1.x+25+tremor.point.x, p->point1.y+25+tremor.point.y);
                        DeleteObject(Pen);
                        DeleteObject(Brush);
                        break;
                case 1:
                        Pen = CreatePen(PS_SOLID,1,RGB(0,100,0));
                        Brush = CreateSolidBrush(RGB(30,200,30));

                        SelectObject(hdc,Brush);
                        SelectObject(hdc,Pen);

                        Rectangle(hdc, p->point1.x-25+tremor.point.x, p->point1.y-10+tremor.point.y, p->point1.x+25+tremor.point.x, p->point1.y+7+tremor.point.y);
                        Rectangle(hdc, p->point1.x-18+tremor.point.x, p->point1.y-25+tremor.point.y, p->point1.x+18+tremor.point.x, p->point1.y-15+tremor.point.y);
                        Rectangle(hdc, p->point1.x-15+tremor.point.x, p->point1.y+10+tremor.point.y, p->point1.x-5+tremor.point.x, p->point1.y+17+tremor.point.y);
                        Rectangle(hdc, p->point1.x+5+tremor.point.x, p->point1.y+10+tremor.point.y, p->point1.x+15+tremor.point.x, p->point1.y+17+tremor.point.y);
                        DeleteObject(Pen);
                        DeleteObject(Brush);

                        Pen = CreatePen(PS_SOLID,1,RGB(0,100,0));
                        Brush = CreateSolidBrush(RGB(30,150,30));
                        SelectObject(hdc,Brush);
                        SelectObject(hdc,Pen);
                        Rectangle(hdc, p->point1.x-20+tremor.point.x ,p->point1.y-5+tremor.point.y, p->point1.x+20+tremor.point.x, p->point1.y+2+tremor.point.y);

                        DeleteObject(Pen);
                        DeleteObject(Brush);

                        Pen = CreatePen(PS_SOLID,1,RGB(30,100,30));
                        SelectObject(hdc,Pen);
                        Brush = CreateSolidBrush(RGB(255,255,255));
                        SelectObject(hdc,Brush);

                        Rectangle(hdc, p->point1.x-14+tremor.point.x, p->point1.y-20+tremor.point.y, p->point1.x-10+tremor.point.x, p->point1.y-5+tremor.point.y);
                        Rectangle(hdc, p->point1.x+10+tremor.point.x, p->point1.y-20+tremor.point.y, p->point1.x+14+tremor.point.x,p->point1.y-5+tremor.point.y);


                        Ellipse(hdc, p->point1.x-10+tremor.point.x, p->point1.y-17+tremor.point.y, p->point1.x+10+tremor.point.x, p->point1.y+17+tremor.point.y);

                        DeleteObject(Pen);
                        DeleteObject(Brush);

                        Pen = CreatePen(PS_SOLID,1,RGB(50,50,50));
                        Brush = CreateSolidBrush(RGB(0,0,0));
                        SelectObject(hdc,Brush);
                        SelectObject(hdc,Pen);

                        Ellipse(hdc, p->point1.x-5+tremor.point.x, p->point1.y-5+tremor.point.y, p->point1.x+5+tremor.point.x, p->point1.y+10+tremor.point.y);

                        DeleteObject(Pen);
                        DeleteObject(Brush);

                        Brush = CreateSolidBrush(RGB(255,255,255));
                        Pen = CreatePen(PS_SOLID,1,RGB(200,200,200));
                        SelectObject(hdc,Brush);
                        SelectObject(hdc,Pen);

                        Rectangle(hdc, p->point1.x-1+tremor.point.x, p->point1.y+17+tremor.point.y, p->point1.x+1+tremor.point.x, p->point1.y+25+tremor.point.y);

                        DeleteObject(Pen);
                        DeleteObject(Brush);
                        break;
                case 2:
                        Pen = CreatePen(PS_SOLID,1,RGB(100,100,0));
                        Brush = CreateSolidBrush(RGB(200,200,30));

                        SelectObject(hdc,Brush);
                        SelectObject(hdc,Pen);

                        Rectangle(hdc, p->point1.x-25+tremor.point.x, p->point1.y-10+tremor.point.y, p->point1.x+25+tremor.point.x, p->point1.y+7+tremor.point.y);
                        Rectangle(hdc, p->point1.x-18+tremor.point.x, p->point1.y-25+tremor.point.y, p->point1.x+18+tremor.point.x, p->point1.y-15+tremor.point.y);
                        Rectangle(hdc, p->point1.x-15+tremor.point.x, p->point1.y+10+tremor.point.y, p->point1.x-5+tremor.point.x, p->point1.y+17+tremor.point.y);
                        Rectangle(hdc, p->point1.x+5+tremor.point.x, p->point1.y+10+tremor.point.y, p->point1.x+15+tremor.point.x, p->point1.y+17+tremor.point.y);
                        DeleteObject(Pen);
                        DeleteObject(Brush);

                        Pen = CreatePen(PS_SOLID,1,RGB(100,100,0));
                        Brush = CreateSolidBrush(RGB(150,150,30));
                        SelectObject(hdc,Brush);
                        SelectObject(hdc,Pen);
                        Rectangle(hdc, p->point1.x-20+tremor.point.x ,p->point1.y-5+tremor.point.y, p->point1.x+20+tremor.point.x, p->point1.y+2+tremor.point.y);

                        DeleteObject(Pen);
                        DeleteObject(Brush);

                        Pen = CreatePen(PS_SOLID,1,RGB(100,100,30));
                        SelectObject(hdc,Pen);
                        Brush = CreateSolidBrush(RGB(255,255,255));
                        SelectObject(hdc,Brush);

                        Rectangle(hdc, p->point1.x-14+tremor.point.x, p->point1.y-20+tremor.point.y, p->point1.x-10+tremor.point.x, p->point1.y-5+tremor.point.y);
                        Rectangle(hdc, p->point1.x+10+tremor.point.x, p->point1.y-20+tremor.point.y, p->point1.x+14+tremor.point.x,p->point1.y-5+tremor.point.y);


                        Ellipse(hdc, p->point1.x-10+tremor.point.x, p->point1.y-17+tremor.point.y, p->point1.x+10+tremor.point.x, p->point1.y+17+tremor.point.y);

                        DeleteObject(Pen);
                        DeleteObject(Brush);

                        Pen = CreatePen(PS_SOLID,1,RGB(50,50,50));
                        Brush = CreateSolidBrush(RGB(0,0,0));
                        SelectObject(hdc,Brush);
                        SelectObject(hdc,Pen);

                        Ellipse(hdc, p->point1.x-5+tremor.point.x, p->point1.y-5+tremor.point.y, p->point1.x+5+tremor.point.x, p->point1.y+10+tremor.point.y);

                        DeleteObject(Pen);
                        DeleteObject(Brush);

                        Brush = CreateSolidBrush(RGB(255,255,255));
                        Pen = CreatePen(PS_SOLID,1,RGB(200,200,200));
                        SelectObject(hdc,Brush);
                        SelectObject(hdc,Pen);

                        Rectangle(hdc, p->point1.x-1+tremor.point.x, p->point1.y+17+tremor.point.y, p->point1.x+1+tremor.point.x, p->point1.y+25+tremor.point.y);

                        DeleteObject(Pen);
                        DeleteObject(Brush);
                        break;
                case 3:
                        Pen = CreatePen(PS_SOLID,1,RGB(100,100,0));
                        Brush = CreateSolidBrush(RGB(200,30,30));

                        SelectObject(hdc,Brush);
                        SelectObject(hdc,Pen);

                        Rectangle(hdc, p->point1.x-25+tremor.point.x, p->point1.y-10+tremor.point.y, p->point1.x+25+tremor.point.x, p->point1.y+7+tremor.point.y);
                        Rectangle(hdc, p->point1.x-18+tremor.point.x, p->point1.y-25+tremor.point.y, p->point1.x+18+tremor.point.x, p->point1.y-15+tremor.point.y);
                        Rectangle(hdc, p->point1.x-15+tremor.point.x, p->point1.y+10+tremor.point.y, p->point1.x-5+tremor.point.x, p->point1.y+17+tremor.point.y);
                        Rectangle(hdc, p->point1.x+5+tremor.point.x, p->point1.y+10+tremor.point.y, p->point1.x+15+tremor.point.x, p->point1.y+17+tremor.point.y);
                        DeleteObject(Pen);
                        DeleteObject(Brush);

                        Pen = CreatePen(PS_SOLID,1,RGB(100,0,0));
                        Brush = CreateSolidBrush(RGB(150,30,30));
                        SelectObject(hdc,Brush);
                        SelectObject(hdc,Pen);
                        Rectangle(hdc, p->point1.x-20+tremor.point.x ,p->point1.y-5+tremor.point.y, p->point1.x+20+tremor.point.x, p->point1.y+2+tremor.point.y);

                        DeleteObject(Pen);
                        DeleteObject(Brush);

                        Pen = CreatePen(PS_SOLID,1,RGB(100,30,30));
                        SelectObject(hdc,Pen);
                        Brush = CreateSolidBrush(RGB(255,255,255));
                        SelectObject(hdc,Brush);

                        Rectangle(hdc, p->point1.x-14+tremor.point.x, p->point1.y-20+tremor.point.y, p->point1.x-10+tremor.point.x, p->point1.y-5+tremor.point.y);
                        Rectangle(hdc, p->point1.x+10+tremor.point.x, p->point1.y-20+tremor.point.y, p->point1.x+14+tremor.point.x,p->point1.y-5+tremor.point.y);


                        Ellipse(hdc, p->point1.x-10+tremor.point.x, p->point1.y-17+tremor.point.y, p->point1.x+10+tremor.point.x, p->point1.y+17+tremor.point.y);

                        DeleteObject(Pen);
                        DeleteObject(Brush);

                        Pen = CreatePen(PS_SOLID,1,RGB(50,50,50));
                        Brush = CreateSolidBrush(RGB(0,0,0));
                        SelectObject(hdc,Brush);
                        SelectObject(hdc,Pen);

                        Ellipse(hdc, p->point1.x-5+tremor.point.x, p->point1.y-5+tremor.point.y, p->point1.x+5+tremor.point.x, p->point1.y+10+tremor.point.y);

                        DeleteObject(Pen);
                        DeleteObject(Brush);

                        Brush = CreateSolidBrush(RGB(255,255,255));
                        Pen = CreatePen(PS_SOLID,1,RGB(200,200,200));
                        SelectObject(hdc,Brush);
                        SelectObject(hdc,Pen);

                        Rectangle(hdc, p->point1.x-1+tremor.point.x, p->point1.y+17+tremor.point.y, p->point1.x+1+tremor.point.x, p->point1.y+25+tremor.point.y);

                        DeleteObject(Pen);
                        DeleteObject(Brush);
                        break;
                }

                p=Next(p);
                }
        }
        void MoveAllEnemys(){
                Enemy *p=head;
                while(p){
                        p->point1.x-=(int)(sin(p->move)*10.);
                        p->move+=0.2;
                        p->point1.x+=(int)(sin(p->move)*10.);
                        p=Next(p);
                }
        }
        Enemy* DeleteEnemy(Enemy *p){
                if(p==0)
                        return 0;
                if(head==p){
                        if(p->next==0){
                                head=0;
                        }
                        else
                        {
                                head=p->next;
                                (p->next)->parent=0;
                        }
                }
                else
                {
                        if(p->next==0){
                                (p->parent)->next=0;
                        }
                        else
                        {
                                (p->parent)->next=p->next;
                                (p->next)->parent=p->parent;
                        }
                }
                Enemy *temp=p->next;
                delete p;
                kolEnemys--;
                return temp;
        }
        void Shoot(int period)
        {
                Enemy *p=head;
                double pi = 3.14159265359;
                while(p){
                        if(rand()%period==1){
                                bullets.AddBullet(p->point1.x,p->point1.y+25,pi*1.5,p->speed,p->bullet,p->power);
                        }
                        p=Next(p);
                }
        }
        void Hits(){
                Enemy *p=head;
                while(p){
                        p->halse-=shipBullets.HitBullets(p->point1.x-25,p->point1.y-25,p->point1.x+25,p->point1.y+25);
                        if(p->halse<=0){
                                blasts.AddBlast(p->point1.x,p->point1.y,2);
                                p=DeleteEnemy(p);
                        }
                        else{
                        p=Next(p);
                        }
                }

        }

};

class Ship{
public:
        POINT point;
        int halse1,halse2,halse3;
        int speed,bullet,power;
        Ship(){
                point.x=500;
                point.y=600;
                halse1=5;
                halse2=5;
                halse3=5;
                speed=10;
                bullet=3;
                power=2;
        }
        void New(int h1,int h2, int h3,int sp,int b,int p){
                halse1=h1;
                halse2=h2;
                halse3=h3;
                speed=sp;
                bullet=b;
                power=p;
        }
        void DrawShip(HDC hdc){
                HPEN Pen;
                HBRUSH Brush;
                if(halse2<=0)
                        return;
                Pen = CreatePen(PS_SOLID,2,RGB(110,110,110));
                Brush = CreateSolidBrush(RGB(150,150,150));
                SelectObject(hdc,Brush);
                SelectObject(hdc,Pen);
                if(halse1>0)
                Rectangle(hdc, point.x-30+tremor.point.x, point.y-18+tremor.point.y, point.x-24+tremor.point.x, point.y+9+tremor.point.y);
                if(halse3>0)
                Rectangle(hdc, point.x+24+tremor.point.x, point.y-18+tremor.point.y, point.x+30+tremor.point.x, point.y+9+tremor.point.y);
                DeleteObject(Pen);
                DeleteObject(Brush);
                if(halse1>0){
                        switch(halse1){
                                case 1:
                                        Pen = CreatePen(PS_SOLID,2,RGB(10,10,10));
                                        Brush = CreateSolidBrush(RGB(120,0,0));
                                        break;
                                case 2:
                                        Pen = CreatePen(PS_SOLID,2,RGB(50,50,50));
                                        Brush = CreateSolidBrush(RGB(150,0,0));
                                        break;
                                case 3:
                                        Pen = CreatePen(PS_SOLID,2,RGB(60,60,60));
                                        Brush = CreateSolidBrush(RGB(175,0,0));
                                        break;
                                case 4:
                                        Pen = CreatePen(PS_SOLID,2,RGB(80,80,80));
                                        Brush = CreateSolidBrush(RGB(200,0,0));
                                        break;
                                case 5:
                                        Pen = CreatePen(PS_SOLID,2,RGB(110,110,110));
                                        Brush = CreateSolidBrush(RGB(220,0,0));
                                        break;
                                default:
                                        Pen = CreatePen(PS_SOLID,2,RGB(110,110,110));
                                        Brush = CreateSolidBrush(RGB(220,0,0));
                                        break;

                        }
                SelectObject(hdc,Brush);
                SelectObject(hdc,Pen);
                Rectangle(hdc, point.x-40 +tremor.point.x, point.y-10+tremor.point.y, point.x+tremor.point.x, point.y+10+tremor.point.y);
                DeleteObject(Pen);
                DeleteObject(Brush);
                }
                if(halse3>0){
                        switch(halse3){
                                case 1:
                                        Pen = CreatePen(PS_SOLID,2,RGB(10,10,10));
                                        Brush = CreateSolidBrush(RGB(120,0,0));
                                        break;
                                case 2:
                                        Pen = CreatePen(PS_SOLID,2,RGB(50,50,50));
                                        Brush = CreateSolidBrush(RGB(150,0,0));
                                        break;
                                case 3:
                                        Pen = CreatePen(PS_SOLID,2,RGB(60,60,60));
                                        Brush = CreateSolidBrush(RGB(175,0,0));
                                        break;
                                case 4:
                                        Pen = CreatePen(PS_SOLID,2,RGB(80,80,80));
                                        Brush = CreateSolidBrush(RGB(200,0,0));
                                        break;
                                case 5:
                                        Pen = CreatePen(PS_SOLID,2,RGB(110,110,110));
                                        Brush = CreateSolidBrush(RGB(220,0,0));
                                        break;
                                default:
                                        Pen = CreatePen(PS_SOLID,2,RGB(110,110,110));
                                        Brush = CreateSolidBrush(RGB(220,0,0));
                                        break;
                        }
                SelectObject(hdc,Brush);
                SelectObject(hdc,Pen);
                Rectangle(hdc, point.x+tremor.point.x, point.y-10+tremor.point.y, point.x+40+tremor.point.x, point.y+10+tremor.point.y);
                DeleteObject(Pen);
                DeleteObject(Brush);
                }
                switch(halse2){
                                case 1:
                                        Pen = CreatePen(PS_SOLID,2,RGB(10,10,10));
                                        Brush = CreateSolidBrush(RGB(150,150,150));
                                        break;
                                case 2:
                                        Pen = CreatePen(PS_SOLID,2,RGB(50,50,50));
                                        Brush = CreateSolidBrush(RGB(175,175,175));
                                        break;
                                case 3:
                                        Pen = CreatePen(PS_SOLID,2,RGB(60,60,60));
                                        Brush = CreateSolidBrush(RGB(200,200,200));
                                        break;
                                case 4:
                                        Pen = CreatePen(PS_SOLID,2,RGB(80,80,80));
                                        Brush = CreateSolidBrush(RGB(225,225,225));
                                        break;
                                case 5:
                                        Pen = CreatePen(PS_SOLID,2,RGB(110,110,110));
                                        Brush = CreateSolidBrush(RGB(255,255,255));
                                        break;
                                default:
                                        Pen = CreatePen(PS_SOLID,2,RGB(110,110,110));
                                        Brush = CreateSolidBrush(RGB(255,255,255));
                                        break;
                }
                SelectObject(hdc,Brush);
                SelectObject(hdc,Pen);
                Ellipse(hdc, point.x-15+tremor.point.x, point.y-45+tremor.point.y, point.x+15+tremor.point.x, point.y+25+tremor.point.y);
                Rectangle(hdc, point.x-20+tremor.point.x, point.y+20+tremor.point.y, point.x+20+tremor.point.x, point.y+35+tremor.point.y);
                DeleteObject(Pen);
                DeleteObject(Brush);
                Pen = CreatePen(PS_SOLID,2,RGB(30,30,30));
                Brush = CreateSolidBrush(RGB(0,0,0));
                SelectObject(hdc,Brush);
                SelectObject(hdc,Pen);
                Ellipse(hdc, point.x-7+tremor.point.x, point.y-28+tremor.point.y, point.x+7+tremor.point.x, point.y+tremor.point.y);
                DeleteObject(Pen);
                DeleteObject(Brush);
        }
        void Hits(){
                if(halse2<=0)
                        return ;
                halse2-=bullets.HitBullets(point.x-15,point.y-45,point.x+15,point.y+25);
                if(halse2<=0){
                        tremor.AddTremor(10);
                        halse2=0;
                        halse1=0;
                        halse3=0;
                        blasts.AddBlast(point.x,point.y,2);
                        blasts.AddBlast(point.x-30,point.y+4,2);
                        blasts.AddBlast(point.x+30,point.y+4,2);
                }
                if(halse1>0){
                        halse1-=bullets.HitBullets(point.x-40,point.y-18,point.x-15,point.y+10);
                if(halse1<=0){
                        tremor.AddTremor(6);
                        halse1=0;
                        blasts.AddBlast(point.x-30,point.y+4,2);
                        }
                }
                if(halse3>0){
                        halse3-=bullets.HitBullets(point.x+15,point.y-18,point.x+40,point.y+10);
                if(halse3<=0){
                        tremor.AddTremor(6);
                        halse3=0;
                        blasts.AddBlast(point.x+30,point.y+4,2);
                        }
                }
        }
        void Fire(){
                double pi = 3.14159265359;
                if(halse2<=0)
                        return;
                if(halse1>0)
                        shipBullets.AddBullet(point.x-28,point.y-18,pi/2,speed,bullet,power);
                if(halse3>0)
                        shipBullets.AddBullet(point.x+28,point.y-18,pi/2,speed,bullet,power);
                if(halse1<=0&&halse3<=0)
                        shipBullets.AddBullet(point.x,point.y,pi/2,speed,2,1);
        }


};
Ship mainShip;

class STATS{
        HPEN Pen;
        HBRUSH Brush;
        RECT rectGraph;
        void DrawShip(HDC hdc);
public:
        STATS();
        void DrawGraphStats(HDC hdc);
        RECT get_rect_to_update() const;
};

RECT STATS :: get_rect_to_update() const {
        return rectGraph;
}

STATS :: STATS() {
        rectGraph.left = mainRect[0].x/8;
        rectGraph.top =  mainRect[1].y/2;
        rectGraph.right = mainRect[0].x-1;
        rectGraph.bottom = mainRect[1].y - 200;
}

void STATS :: DrawGraphStats(HDC hdc){
        Pen = CreatePen(PS_SOLID,3,RGB(0,0,100));
        Brush = CreateSolidBrush(RGB(0,0,0));
        SelectObject(hdc,Pen);
        SelectObject(hdc,Brush);
        Rectangle(hdc,rectGraph.left,rectGraph.top,rectGraph.right,rectGraph.bottom);
        DeleteObject(Pen);
        DeleteObject(Brush);
        DrawShip(hdc);
}

void STATS :: DrawShip(HDC hdc) {
                switch(mainShip.halse1){
                                case 0:
                                        Pen = CreatePen(PS_SOLID,2,RGB(10,10,10));
                                        Brush = CreateSolidBrush(RGB(50,50,50));
                                        break;
                                case 1:
                                        Pen = CreatePen(PS_SOLID,2,RGB(10,10,10));
                                        Brush = CreateSolidBrush(RGB(220,0,0));
                                        break;
                                case 2:
                                        Pen = CreatePen(PS_SOLID,2,RGB(50,50,50));
                                        Brush = CreateSolidBrush(RGB(200,160,0));
                                        break;
                                case 3:
                                        Pen = CreatePen(PS_SOLID,2,RGB(60,60,60));
                                        Brush = CreateSolidBrush(RGB(180,180,0));
                                        break;
                                case 4:
                                        Pen = CreatePen(PS_SOLID,2,RGB(80,80,80));
                                        Brush = CreateSolidBrush(RGB(130,180,0));
                                        break;
                                case 5:
                                        Pen = CreatePen(PS_SOLID,2,RGB(110,110,110));
                                        Brush = CreateSolidBrush(RGB(0,220,0));
                                        break;
                                default:
                                        Pen = CreatePen(PS_SOLID,2,RGB(110,110,110));
                                        Brush = CreateSolidBrush(RGB(0,220,0));
                                        break;
                }
        SelectObject(hdc,Brush);
        SelectObject(hdc,Pen);

        Rectangle(hdc,rectGraph.left+10,rectGraph.top+50,rectGraph.right-55,rectGraph.bottom - 55);
        DeleteObject(Pen);
        DeleteObject(Brush);
        switch(mainShip.halse2){
                                case 0:
                                        Pen = CreatePen(PS_SOLID,2,RGB(10,10,10));
                                        Brush = CreateSolidBrush(RGB(50,50,50));
                                        break;
                                case 1:
                                        Pen = CreatePen(PS_SOLID,2,RGB(10,10,10));
                                        Brush = CreateSolidBrush(RGB(220,0,0));
                                        break;
                                case 2:
                                        Pen = CreatePen(PS_SOLID,2,RGB(50,50,50));
                                        Brush = CreateSolidBrush(RGB(200,160,0));
                                        break;
                                case 3:
                                        Pen = CreatePen(PS_SOLID,2,RGB(60,60,60));
                                        Brush = CreateSolidBrush(RGB(180,180,0));
                                        break;
                                case 4:
                                        Pen = CreatePen(PS_SOLID,2,RGB(80,80,80));
                                        Brush = CreateSolidBrush(RGB(130,180,0));
                                        break;
                                case 5:
                                        Pen = CreatePen(PS_SOLID,2,RGB(110,110,110));
                                        Brush = CreateSolidBrush(RGB(0,220,0));
                                        break;
                                default:
                                        Pen = CreatePen(PS_SOLID,2,RGB(110,110,110));
                                        Brush = CreateSolidBrush(RGB(0,220,0));
                                        break;
                }
        SelectObject(hdc,Brush);
        SelectObject(hdc,Pen);

        Ellipse(hdc,rectGraph.left + 30,rectGraph.top + 30,rectGraph.right - 30,rectGraph.bottom - 30);
        Ellipse(hdc,rectGraph.left + 40,rectGraph.top + 45,rectGraph.right - 40,rectGraph.bottom - 50);
        Rectangle(hdc,rectGraph.left+20,rectGraph.top+85,rectGraph.right-20,rectGraph.bottom - 25);
        DeleteObject(Pen);
        DeleteObject(Brush);

        switch(mainShip.halse3){
                                case 0:
                                        Pen = CreatePen(PS_SOLID,2,RGB(10,10,10));
                                        Brush = CreateSolidBrush(RGB(50,50,50));
                                        break;
                                case 1:
                                        Pen = CreatePen(PS_SOLID,2,RGB(10,10,10));
                                        Brush = CreateSolidBrush(RGB(220,0,0));
                                        break;
                                case 2:
                                        Pen = CreatePen(PS_SOLID,2,RGB(50,50,50));
                                        Brush = CreateSolidBrush(RGB(200,160,0));
                                        break;
                                case 3:
                                        Pen = CreatePen(PS_SOLID,2,RGB(60,60,60));
                                        Brush = CreateSolidBrush(RGB(180,180,0));
                                        break;
                                case 4:
                                        Pen = CreatePen(PS_SOLID,2,RGB(80,80,80));
                                        Brush = CreateSolidBrush(RGB(130,180,0));
                                        break;
                                case 5:
                                        Pen = CreatePen(PS_SOLID,2,RGB(110,110,110));
                                        Brush = CreateSolidBrush(RGB(0,220,0));
                                        break;
                                default:
                                        Pen = CreatePen(PS_SOLID,2,RGB(110,110,110));
                                        Brush = CreateSolidBrush(RGB(0,220,0));
                                        break;
                }
        SelectObject(hdc,Brush);
        SelectObject(hdc,Pen);
        Rectangle(hdc,rectGraph.left+55,rectGraph.top+50,rectGraph.right-10,rectGraph.bottom - 55);
        DeleteObject(Pen);
        DeleteObject(Brush);

        Pen = CreatePen(PS_SOLID,2,RGB(110,110,110));
        Brush = CreateSolidBrush(RGB(0,100,0));
        SelectObject(hdc,Brush);
        SelectObject(hdc,Pen);
        Rectangle(hdc,rectGraph.left + 40,rectGraph.top + 20,rectGraph.right - 40,rectGraph.top +30);
        Rectangle(hdc,rectGraph.left + 20,rectGraph.top + 40,rectGraph.right - 60,rectGraph.top +50);
        Rectangle(hdc,rectGraph.left + 60,rectGraph.top + 40,rectGraph.right - 20,rectGraph.top +50);
        DeleteObject(Pen);
        DeleteObject(Brush);
}

class STARS{
        int starsNum;
        int starSpeed;
        POINT *mas;
public:
        STARS(unsigned s, unsigned num);
        void starsSet();
        void starsDraw(HDC hdc) const;
};

STARS :: STARS(unsigned s, unsigned num) {
  starSpeed = s;
  starsNum = num;
  mas = new POINT[starsNum];

  srand(time(NULL));
  for(int i = 0; i < starsNum; i++){
        mas[i].x = (rand()%(mainRect[1].x-mainRect[0].x)) + mainRect[0].x;
        mas[i].y = (((mainRect[1].y-mainRect[0].y)/starsNum)*i)+mainRect[0].y;
        }
}

void STARS :: starsSet() {
for(int i = 0; i < starsNum; i++){
        mas[i].y += starSpeed;
        if(mas[i].y > mainRect[1].y){
                mas[i].y = 50;
                mas[i].x = (rand()%800) + 100;
        }
}
}

void STARS :: starsDraw(HDC hdc) const{
for(int i = 0; i < starsNum; i++) SetPixel(hdc,mas[i].x,mas[i].y,RGB(255,255,255));
}


struct Level{
        int kol,body,halse,bullet,pover,speed;
};

Level level[5];
static int l=0;
static int a=0;
STARS star(2,30);
STATS stat;
//Enemys enemys(8,2,5,3,3,7);//kol,body,halse,bullet,power,speed
Enemys enemys;




LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE hInst;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
 HWND hWndMain;

 hInst =   hInstance;

 char szClassName[] = "MainWndClass";
 MSG msg;
 WNDCLASSEX wc;

 wc.cbSize = sizeof(wc);
 wc.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS | CS_OWNDC;
 wc.lpfnWndProc = WndProc;
 wc.cbClsExtra = 0;
 wc.cbWndExtra = 0;
 wc.hInstance = hInstance;
 wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
 wc.hCursor = LoadCursor(NULL, IDC_ARROW);
 wc.hbrBackground = CreatePatternBrush(LoadImage(NULL,"back.bmp",IMAGE_BITMAP,0,0,LR_LOADFROMFILE));
 wc.lpszMenuName = NULL;
 wc.lpszClassName = szClassName;
 wc.hIconSm = LoadIcon(NULL, IDI_WARNING);

 if(!RegisterClassEx(&wc)) {
   MessageBox(NULL, "Cannot register class", "Error", MB_OK);
   return 0;
 }

 hWndMain = CreateWindow(szClassName, "Game. pre-alpha buil.v014", WS_MAXIMIZE | WS_CAPTION | WS_VISIBLE | WS_TABSTOP, CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, (HWND)NULL, (HMENU)NULL, (HINSTANCE) hInstance, NULL);

 if(!hWndMain) {
   MessageBox(NULL, "Cannot create main window", "Error", MB_OK);
   return 0;
 }

 ShowWindow(hWndMain, SW_MAXIMIZE);
 //ShowWindow(hButton1, nCmdShow);
 //UpdateWindow(hWndMain);


 while(GetMessage(&msg, NULL, 0, 0)) {
   TranslateMessage(&msg);
   DispatchMessage(&msg);
 }

 return msg.wParam;

}

LRESULT CALLBACK WndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {

HDC hdc;
PAINTSTRUCT ps;
RECT rect;

HWND hButton1;


//rect update
RECT updateRect;
updateRect.left = mainRect[0].x;
updateRect.top = mainRect[0].y;
updateRect.right = mainRect[1].x;
updateRect.bottom = mainRect[1].y;
//rect update

//rect color
static HPEN mainRectLine, temp;
static HBRUSH mainRectBack , old;
LOGBRUSH logMRL;
logMRL.lbStyle = BS_SOLID;
logMRL.lbColor = RGB(0,0,100);
//rect color

//ship
static POINT ship;
static POINT bullet;
char coord[100];
//ship

//enemy
static POINT eship;
static bool status = 1;
//enemy


switch(uMsg) {
case WM_CREATE:
                hButton1 = CreateWindow("BUTTON", "exit", WS_CHILD| WS_VISIBLE, 0, 0, 100, 20, hwnd, (HMENU)BUTTON1, (HINSTANCE) hInst, NULL);

                level[0].kol=6;level[0].body=1;level[0].halse=2;
                level[0].bullet=1;level[0].pover=1;level[0].speed=5;
                level[1].kol=7;level[1].body=2;level[1].halse=3;
                level[1].bullet=2;level[1].pover=2;level[1].speed=6;
                level[2].kol=8;level[2].body=2;level[2].halse=4;
                level[2].bullet=3;level[2].pover=3;level[2].speed=7;
                level[3].kol=9;level[3].body=3;level[3].halse=5;
                level[3].bullet=3;level[3].pover=4;level[3].speed=8;
                level[4].kol=10;level[4].body=3;level[4].halse=6;
                level[4].bullet=4;level[4].pover=5;level[4].speed=9;
                srand(time(NULL));
                SetTimer(hwnd,1,40,NULL);
                mainRectBack = CreateSolidBrush(RGB(0,0,0));
                mainRectLine = ExtCreatePen(PS_GEOMETRIC | PS_SOLID | PS_ENDCAP_SQUARE,3,&logMRL,NULL,NULL);
                temp = CreatePen(PS_SOLID,3,RGB(255,255,255));



                break;
case WM_COMMAND:
                switch(LOWORD(wParam)){
                case BUTTON1:
                        switch(HIWORD(wParam)){
                                case WM_LBUTTONDOWN:
                                                KillTimer(hwnd,1);
                                                DeleteObject(temp);
                                                DeleteObject(mainRectLine);
                                                DeleteObject(mainRectBack);
                                                DestroyWindow(hwnd);
                                                PostQuitMessage(0);
                                                break;
                                                }

                }

                break;
case WM_KEYDOWN:
                switch((int) wParam){
                                case VK_ESCAPE:
                                                KillTimer(hwnd,1);
                                                DeleteObject(temp);
                                                DeleteObject(mainRectLine);
                                                DeleteObject(mainRectBack);
                                                DestroyWindow(hwnd);
                                                PostQuitMessage(0);
                                                break;
                }
                break;
case WM_TIMER :
                if(enemys.kolEnemys<=0){
                        if(l<5)
                        if(a>=50){
                        enemys.AddAllEnemys(level[l].kol,level[l].body,level[l].halse,level[l].bullet,level[l].pover,level[l].speed);
                        l++;
                        a=0;
                        }
                        a++;
                }
                if(mainShip.halse2<=0){
                        if(a>=50){
                        mainShip.New(5,5,5,9,3,2);
                        a=0;
                        }
                        a++;
                }
                star.starsSet();
                if(bullet.y > 100)bullet.y -= 45;
                if(bullet.y < 150 && bullet.y > 50 && bullet.x > eship.x-25 && bullet.x < eship.x+25)  status = 0;
                enemys.MoveAllEnemys();
                enemys.Shoot(400);
                bullets.BulletsFly();
                shipBullets.BulletsFly();

                tremor.DecayTremor();
                blasts.DecayBlasts();
                mainShip.Hits();
                enemys.Hits();


                InvalidateRect(hwnd,&stat.get_rect_to_update(),0);
                InvalidateRect(hwnd,&updateRect,0);
                break;
case WM_MOUSEMOVE:

                mainShip.point.x=LOWORD(lParam);
                if(LOWORD(lParam)<mainRect[0].x+50)
                        mainShip.point.x=mainRect[0].x+50;
                if(LOWORD(lParam)>mainRect[1].x-50)
                        mainShip.point.x=mainRect[1].x-50;
                /*ship.x = LOWORD(lParam);
                ship.y = HIWORD(lParam);
                eship.x = LOWORD(lParam);
                eship.y = HIWORD(lParam);*/
                break;
case WM_LBUTTONDOWN:
                mainShip.Fire();
                break;
case WM_PAINT:
                hdc = BeginPaint(hwnd,&ps);
                //SetBkMode(hdc,TRANSPARENT);
                GetClientRect(hwnd,&rect);

                //main RECT
                SelectObject(hdc,mainRectLine);
                old = SelectObject(hdc,mainRectBack);
                Rectangle(hdc,mainRect[0].x,mainRect[0].y,mainRect[1].x,mainRect[1].y);
                //main RECT

                star.starsDraw(hdc);

                //ship navigation
                SelectObject(hdc,temp);
                /*if(ship.x-25 > mainRect[0].x + 3 && ship.x+25 < mainRect[1].x - 3)Rectangle(hdc,ship.x-25,500,ship.x+25,550);
                else if(ship.x-25 < mainRect[0].x + 3) Rectangle(hdc,100,500,150,550);
                else if(ship.x+25 > mainRect[1].x - 3) Rectangle(hdc,850,500,900,550); */
                //ship navigation

                /*if(status){
                //Eship nav
                if(eship.x-25 > mainRect[0].x + 3 && eship.x+25 < mainRect[1].x - 3)Rectangle(hdc,eship.x-25,60,eship.x+25,150);
                else if(eship.x-25 < mainRect[0].x + 3) Rectangle(hdc,100,60,150,150);
                else if(eship.x+25 > mainRect[1].x - 3) Rectangle(hdc,850,60,900,150);
                //Eship nav}
                } */

                //bullet
                SelectObject(hdc,old);
                SetPixel(hdc,bullet.x,bullet.y,RGB(255,0,0));
                //bullet

                //sys inf
                sprintf(coord," Level   %d",l+1);
                DrawText(hdc,coord,-1,&updateRect,DT_RIGHT);
                //sys inf
                enemys.DrawAllEnemys(hdc);
                stat.DrawGraphStats(hdc);
                bullets.DrawAllBullets(hdc);
                shipBullets.DrawAllBullets(hdc);
                mainShip.DrawShip(hdc);
                blasts.DrawAllBlasts(hdc);
                EndPaint(hwnd,&ps);
                break;
case WM_CLOSE:
                KillTimer(hwnd,1);
                DeleteObject(temp);
                DeleteObject(mainRectLine);
                DeleteObject(mainRectBack);
                DestroyWindow(hwnd);
                break;
case WM_DESTROY:
                PostQuitMessage(0);
                break;
default:
                return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

return 0;
}

/*BOOL CALLBACK DlgProc(HWND hwnd, UINT umsg, WPARAM wparam, LPARAM lparam) {
        switch(umsg){
                case WM_INITDIALOG:
                        return 1;
                        break;
        }
        return 0;
} */
 