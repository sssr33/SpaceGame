/*BUGS:
        1.����������� ������ ������.
                �������������:
                        1.�������� �������� �� ��������� ���������� ��������� � ���� ��������
                        
        2.�������(��������� ��������� �������� ��������) ������� ������� �� �������� ��������.//������
                �������������:
                        1.�������� ������, �� ���-�� ������.

        3.������� �������� end �� �������� � ��������� ��������� ����� ��� ������.//������

        4.����������� ������� �������� ����� � ��������� ������ ��������, ��� ����� ������� ����������� ������
                �������������
                        1.����������� ������� ��������
        5.����������� ������ ������ ��� ������� ����.

*/
#include <windows.h>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <math.h>
#include <list.h>

//������ ��������� �������������� �� �������
#define AI_BOTTOM 0  //not work
#define AI_TOP 1     //work
#define AI_LEFT 2    //not work
#define AI_RIGHT 3   //not work
//������ ��������� �������������� �� �������

//����������� ��������� �����
#define GUN_UP 0     //work
#define GUN_DOWN 1   //work
//����������� ��������� �����

#define BSMOKE_WHITE 0
#define BSMOKE_RED 1
#define BSMOKE_GREEN 2
#define BSMOKE_BLUE 3

RECT GetMainRect();

RECT GetRectFromPoint(RECT,POINT,unsigned);

bool IsPointInRect(RECT,POINT);

POINT mainRect[2] = {{100,50},{900,650}};

int bsize;
int expl_size;

class EXPLOSION {
        POINT expl_pos;
        HBRUSH expl_color_out;
        HPEN expl_out;

        HBRUSH expl_color_inner;
        HPEN expl_inner;

        bool status;
        unsigned expl_radius;
public:
        EXPLOSION(POINT);
        //~EXPLOSION();
        void set_explosion(POINT);
        void explosion_anim(HDC);
        void set_status(bool a) { status = a; }
};

EXPLOSION :: EXPLOSION(POINT pos){
expl_pos = pos;



        status = 1;
        expl_radius = 0;
        expl_color_out = CreateSolidBrush(RGB(236,0,0));
        expl_out = CreatePen(PS_SOLID,2,RGB(255,56,6));

        expl_color_inner = CreateSolidBrush(RGB(255,100,100));
        expl_inner = CreatePen(PS_SOLID,2,RGB(255,56,56));

}

void EXPLOSION :: set_explosion(POINT pos) {
        expl_pos = pos;
        status = 0;
        expl_radius = 0;
        expl_color_out = CreateSolidBrush(RGB(236,0,0));
        expl_out = CreatePen(PS_SOLID,2,RGB(255,56,6));

        expl_color_inner = CreateSolidBrush(RGB(255,100,100));
        expl_inner = CreatePen(PS_SOLID,2,RGB(255,56,56));
}

void EXPLOSION :: explosion_anim(HDC hdc) {
static float i = 0, i2 = 0;
static float j = 0;

if(status){

    SelectObject(hdc,expl_color_out);
    SelectObject(hdc,expl_out);

    Rectangle(hdc,expl_pos.x - i, expl_pos.y + i,expl_pos.x + i, expl_pos.y - i);

    SetPixel(hdc,expl_pos.x + (i + j),expl_pos.y + (i + j),RGB(236,0,0));


    SetPixel(hdc,expl_pos.x - (i + j),expl_pos.y - (i + j),RGB(236,0,0));

    SetPixel(hdc,expl_pos.x + (i + j),expl_pos.y,RGB(236,0,0));

    SetPixel(hdc,expl_pos.x,expl_pos.y + (i + j),RGB(236,0,0));

    SelectObject(hdc,expl_color_inner);
    SelectObject(hdc,expl_inner);
    Rectangle(hdc,expl_pos.x - i2, expl_pos.y + i2,expl_pos.x + i2, expl_pos.y - i2);
    if(i > 5){ status = 0; i = 0; i2 = 0; j = 0; }
    i += 0.5;
    i2 += 0.45;
    j += 5;
    //DeleteObject(expl_out);
    //DeleteObject(expl_color);
    }
    }


class BULLET {
        POINT start_bullet_pos;
        POINT pos_of_bullet;
        HPEN Pen;
        void DrawModel(HDC, POINT) const;
        void DrawSmoke(HDC, POINT, int,unsigned);
public:
        BULLET(POINT);
        void DrawInPoint(HDC,POINT,unsigned,unsigned);
        POINT GetPos() const;
};

BULLET :: BULLET(POINT start_pos){
        expl_size++;
        start_bullet_pos = pos_of_bullet = start_pos;
}

POINT BULLET :: GetPos() const { return pos_of_bullet; }

void BULLET :: DrawInPoint(HDC hdc, POINT pos, unsigned smoke_lenght,unsigned mode = BSMOKE_WHITE){
        pos_of_bullet = pos;
        int smoke_pixels = start_bullet_pos.y - pos.y;
        if(smoke_pixels > 0 && (smoke_pixels > smoke_lenght + 1)) smoke_pixels = smoke_lenght;
        else if(smoke_pixels < 0 && (abs(smoke_pixels) > smoke_lenght + 1)) smoke_pixels = 0 - smoke_lenght;

        DrawSmoke(hdc,pos,smoke_pixels,mode);
        
        Pen = SelectObject(hdc,CreatePen(PS_SOLID,2,RGB(255,0,0)));
        DrawModel(hdc, pos);
        DeleteObject(SelectObject(hdc,Pen));
}

void BULLET :: DrawModel(HDC hdc, POINT pos) const{
        MoveToEx(hdc,pos.x,pos.y,NULL);
        LineTo(hdc,pos.x,pos.y + 3);
}

void BULLET :: DrawSmoke(HDC hdc,POINT pos, int smoke_pixels, unsigned mode){
        POINT smoke;
        int smoke_direction = 1;
        float white_to_black = 255;
        float color_change_speed = white_to_black / abs(smoke_pixels);

        if(smoke_pixels < 0) {
                        smoke_pixels = abs(smoke_pixels);
                        smoke_direction = -1;
                        }
        smoke.x = pos.x;
        smoke.y = pos.y + smoke_direction;

        for(unsigned i = 0; i < smoke_pixels; i++) {
                switch(mode){
                        case BSMOKE_RED:
                                SetPixel(hdc,smoke.x,smoke.y,RGB(white_to_black,0,0));
                                break;
                        case BSMOKE_GREEN:
                                SetPixel(hdc,smoke.x,smoke.y,RGB(0,white_to_black,0));
                                break;
                        case BSMOKE_BLUE:
                                SetPixel(hdc,smoke.x,smoke.y,RGB(0,0,white_to_black));
                                break;
                        default:
                                SetPixel(hdc,smoke.x,smoke.y,RGB(white_to_black,white_to_black,white_to_black));
                                break;
                }
                smoke.y += smoke_direction;
                white_to_black -= color_change_speed;
        }
}

class GUN{
        list<BULLET> bullets;
        list<EXPLOSION> explosions;
        HPEN bullet_color;
        HPEN explosion_out;
        HBRUSH explosion_inner;
public:
        GUN();
        void shoot(POINT);
        void hit(); //full version coming soon...
        void MoveAllBullets(HDC,unsigned,unsigned,unsigned);
};

GUN :: GUN() {
        bullet_color = CreatePen(PS_SOLID,3,RGB(255,0,0));
        //explosion_out = CreatePen(PS_SOLID,4,RGB(255,56,6));
        //explosion_inner = CreateSolidBrush(RGB(236,0,0));
        POINT void_point;
        bullets.push_front(void_point);
        explosions.push_front(void_point);
}


class SWITCH {
        bool *mas;
        unsigned size;
public:
        SWITCH(unsigned);
        void SetActive(unsigned);
        bool IsActive(unsigned) const;
};

SWITCH :: SWITCH(unsigned s = 10){
        size = s;
        mas = new bool[size];
        for(unsigned i = 0; i < size; i++) mas[i] = 0;
}

void SWITCH :: SetActive(unsigned index){
        if(index >= size) return;
       
        for(unsigned i = 0; i < size; i++){
                if(i == index)mas[i] = 1;
                else mas[i] = 0;
        }
}

bool SWITCH :: IsActive(unsigned index) const{
        if(index < size) return mas[index];
        else return 0;
}

class ENEMY {
   //     friend class AI;
        int a;
        int b;
        unsigned health;
        SWITCH direction;
        POINT model[2];
        bool status;
        bool target_detect;

        HPEN pen;
        HBRUSH brush;
public:
        ENEMY() { a = 20; b = 20; target_detect = status = 1; direction.SetActive(0); health = 100; }
        void draw_enemy(HDC hdc);
        void set_model_pos(unsigned x, unsigned y);
        void anim_test(unsigned x, unsigned lim1 ,unsigned lim2);
        POINT get_Xt_Xb_pos() const;
        POINT get_gun_pos();
        bool get_status() const;
        RECT get_enemy_rect() const;
        void damage(unsigned damage);
        void Draw_respawn_portal(HDC);
};

void ENEMY :: Draw_respawn_portal(HDC hdc) {

        if(!status) {
                pen = SelectObject(hdc,CreatePen(PS_SOLID,3,RGB(0,23,40)));
                brush = SelectObject(hdc,CreateSolidBrush(RGB(0,35,62)));
                Ellipse(hdc,model[1].x,model[1].y-7,model[0].x,model[0].y+7);
                DeleteObject(SelectObject(hdc,pen));
                DeleteObject(SelectObject(hdc,brush));
        }

}

void ENEMY :: damage(unsigned damage){
        if(health) health -= damage;
        else status = 0;
}

RECT ENEMY :: get_enemy_rect() const {
        RECT pos;

        pos.left = model[0].x;
        pos.top = model[0].y;
        pos.right = model[1].x;
        pos.bottom = model[1].y;

        return pos;
}

POINT ENEMY :: get_gun_pos() {
        POINT pos;

        pos.y = model[1].y + 3;
        pos.x = (model[0].x + model[1].x) / 2;

        return pos;
}

bool ENEMY :: get_status() const {
        return status;
}

POINT ENEMY :: get_Xt_Xb_pos() const {
POINT pos;
pos.x = model[0].x;
pos.y = model[1].x;

return pos;
}

void ENEMY :: anim_test(unsigned x, unsigned lim1 ,unsigned lim2){
  if(status){
  if(x > lim1 && x < lim2){
        target_detect = 1;
        if((x > (model[0].x + model[1].x) / 2) && (model[0].x > lim1) && (model[1].x < lim2)){ model[0].x += 4; model[1].x += 4; }
        else if((x < (model[0].x + model[1].x) / 2) && (model[0].x > lim1) && (model[1].x < lim2)) { model[0].x -= 4; model[1].x -= 4; }
        else if((x < (model[0].x + model[1].x) / 2) && (model[0].x > lim1) && (model[1].x <= lim2+6)) { model[0].x -= 4; model[1].x -= 4; }
        else if((x > (model[0].x + model[1].x) / 2) && (model[0].x >= lim1-6) && (model[1].x < lim2)) { model[0].x += 4; model[1].x += 4; }
  }
  else if(x < lim1 || x > lim2){
        target_detect = 0;
        if(direction.IsActive(0) && (model[0].x > lim1) && (model[1].x < lim2)) { model[0].x += 2; model[1].x += 2; }
        else if(direction.IsActive(0) && (model[0].x > lim1) && (model[1].x <= lim2+6))  { direction.SetActive(1); model[0].x -= 2; model[1].x -= 2; }
        else if(direction.IsActive(1) && (model[0].x > lim1) && (model[1].x < lim2)) { model[0].x -= 2; model[1].x -= 2; }
        else if(direction.IsActive(1) && (model[0].x >= lim1-6) && (model[1].x < lim2)) { direction.SetActive(0); model[0].x += 2; model[1].x += 2; }
  }
}
}

void ENEMY :: set_model_pos(unsigned x, unsigned y) {
        model[0].x = x - a;
        model[0].y = y - b;
        model[1].x = x + a;
        model[1].y = y + b;
}

void ENEMY :: draw_enemy(HDC hdc){
        if(status) {
        Rectangle(hdc,model[0].x,model[0].y,model[1].x,model[1].y);
        SetPixel(hdc,(model[0].x + model[1].x) / 2, (model[0].y + model[1].y) / 2,RGB(255,0,0));
        }
}

class PLAYER{
        POINT player_pos;
public:
        void set_pos(POINT);
        void set_posX(unsigned);
        POINT get_pos();
};

void PLAYER :: set_posX(unsigned x) {
        player_pos.x = x;
}

void PLAYER :: set_pos(POINT p) {
        player_pos = p;
}

POINT PLAYER :: get_pos() {
        return player_pos;
}

class AI{
        unsigned sectors_num;
        unsigned sector_lenght;
        unsigned sector_middle;
        RECT *sectors;
        unsigned mode;
        unsigned enemy_num;
        POINT *respawn_point;
        ENEMY *en_ship;

        list<BULLET> *gun;

        PLAYER player;
        RECT player_ship;
        GUN player_gun;
        unsigned player_ship_size;
        void draw_player(HDC);

        unsigned active_guns;
        list<EXPLOSION> explosions;
        HPEN Pen;
        HBRUSH Brush;

        void division(unsigned max_coord,unsigned min_coord, unsigned top, unsigned bottom);
        void set_respawn_points();
        unsigned set_sector_middle(unsigned a, unsigned b);
        POINT set_size(HDC hdc,POINT pos);
        void hit(list<BULLET> &g);
        void draw_bullets(HDC,list<BULLET> &,unsigned,unsigned,unsigned,unsigned);
        void enemy_control();
        void draw_explosions(HDC);
public:

        void start_game(HDC hdc,unsigned sect, unsigned m);
        void enemy_attack();

        void player_pos_set(unsigned posX);
        void player_gun_shoot();

        void main_calc();
        void main_draw(HDC);
};

void AI :: draw_explosions(HDC hdc) {
        if(explosions.size()){
        list<EXPLOSION> :: iterator p = explosions.begin();
                //while(/*p != explosions.end()*/explosions.size()) {
                        p->explosion_anim(hdc);
                       // explosions.pop_front();
                       // p = explosions.begin();
                        //p++;
                //}
        }
}

void AI :: draw_bullets(HDC hdc,list<BULLET> &g,unsigned smoke_lenght,unsigned speed = 25,unsigned bullet_direction = GUN_UP,unsigned smoke_color = BSMOKE_WHITE) {
        POINT pos_change;

        if(g.size()) {
        list<BULLET> :: iterator p = g.begin();

        while(p != g.end()) {
                pos_change = p->GetPos();

                if(bullet_direction == GUN_UP) pos_change.y -= speed;
                if(bullet_direction == GUN_DOWN) pos_change.y += speed;

                p->DrawInPoint(hdc, pos_change, smoke_lenght,smoke_color);
                
                p++;
        }
}}

void AI :: hit(list<BULLET> &g) {
        bsize = g.size();
        POINT check_pos;
        RECT enemy_check;
        RECT mainR =  GetMainRect();

        list<BULLET> :: iterator p = g.begin();

        while(p != g.end()) {
                check_pos = p->GetPos();


                if((check_pos.y < mainRect[0].y || check_pos.y > mainRect[1].y) && g.size() > 1) { explosions.push_front(check_pos); g.erase(p--); }
                else if((check_pos.x < player_ship.right && check_pos.x > player_ship.left && check_pos.y < player_ship.bottom && check_pos.y > player_ship.top) && g.size()) { explosions.push_front(check_pos); g.erase(p--); }
                else for(int i = 0; i < enemy_num; i++) {
                        enemy_check = en_ship[i].get_enemy_rect();
                        if((check_pos.x < enemy_check.right && check_pos.x > enemy_check.left && check_pos.y < enemy_check.bottom && check_pos.y > enemy_check.top) && g.size()) { explosions.push_front(check_pos); en_ship[i].damage(20); g.erase(p--); }
                }
                p++;
        } 
}

void AI :: draw_player(HDC hdc) {
        player_ship = GetRectFromPoint(player_ship,player.get_pos(),player_ship_size);
        Rectangle(hdc,player_ship.left,player_ship.top,player_ship.right,player_ship.bottom);
}

void AI :: player_gun_shoot(){
        POINT pos = player.get_pos();
        pos.y = pos.y - player_ship_size/2;
        gun[0].push_front(pos);
        explosions.push_front(pos);
}

void AI :: main_calc() {
        enemy_control();

        for(int i = 0; i < sectors_num + 1; i++) {
                hit(gun[i]);
        }
}

void AI :: main_draw(HDC hdc){

        Pen = SelectObject(hdc,CreatePen(PS_SOLID,3,RGB(0,72,145)));
        draw_player(hdc);
        DeleteObject(SelectObject(hdc,Pen));

        Pen = SelectObject(hdc,CreatePen(PS_SOLID,3,RGB(255,255,255)));
        for(int i = 0; i < enemy_num; i++) { en_ship[i].draw_enemy(hdc); en_ship[i].Draw_respawn_portal(hdc); }
        for(int i = 0; i < 2; i++){
        MoveToEx(hdc,sectors[i].left,sectors[i].top,NULL);
        LineTo(hdc,sectors[i].left,sectors[i].bottom);
        }
        DeleteObject(SelectObject(hdc,Pen));

        draw_bullets(hdc,gun[0],150,25,GUN_UP);

        for(int i = 1; i < 4;i++){
        draw_bullets(hdc,gun[i],150,25,GUN_DOWN,BSMOKE_RED);
        }

        if(explosions.size())draw_explosions(hdc);
}

void AI :: player_pos_set(unsigned posX) {
        if((posX > (mainRect[0].x + player_ship_size/2)) && (posX < (mainRect[1].x - player_ship_size/2))) player.set_posX(posX);
}

POINT AI :: set_size(HDC hdc, POINT pos) {
        int x;
        int y;

        x = GetDeviceCaps(hdc,HORZRES) - 100;
        y = (GetDeviceCaps(hdc,VERTRES)/100) * 90;
        pos.x = x;
        pos.y = y;

        return pos;
}

void AI :: enemy_attack() {
int temp = 1;

        for(int i = 0; i < enemy_num; i += 3){
              for(int k = i; k < 3 + i;k++){
                if(en_ship[k].get_status()) { gun[temp].push_front(en_ship[k].get_gun_pos()); temp++; break;}
              }
        }
active_guns = temp - 1;
}

void AI :: enemy_control() {
unsigned start = 0, end = 3;
POINT posX = player.get_pos();

        for(int i = 0; i < sectors_num; i++) {
        for(int start = 0; start < end; start++) {
                en_ship[start].anim_test(posX.x,sectors[i].left,sectors[i].right);
        }
        start = end;
        end += 3;
        }
}

void AI :: start_game(HDC hdc, unsigned sect, unsigned m) {
        enemy_num = sect*3;

        player_ship_size = 50;

        sectors_num = sect;
        gun = new list<BULLET>[sectors_num + 1];
        en_ship = new ENEMY[enemy_num];
        sectors = new RECT[sectors_num];
        respawn_point = new POINT[enemy_num];
        POINT player_start;

        POINT void_point;
        for(int i = 0; i < sectors_num + 1; i++) {
                gun[i].push_front(void_point);
        }
        explosions.push_front(void_point);

        mainRect[1] = set_size(hdc,mainRect[1]);

                switch(m) {
                case AI_BOTTOM:

                                division(mainRect[1].x,mainRect[0].x, mainRect[1].y,(mainRect[1].y - mainRect[0].y) - ((mainRect[1].y - mainRect[0].y)/3));//height = 450
                                sector_middle = set_sector_middle(sectors[sectors_num-1].left,sectors[sectors_num-1].right);
                                set_respawn_points();
                                player_start.x = (mainRect[0].x + mainRect[1].x) / 2;
                                player_start.y = mainRect[0].y + 40;
                                player.set_pos(player_start);
                                break;
                case AI_TOP:
                                division(mainRect[1].x,mainRect[0].x, mainRect[0].y,(mainRect[1].y - mainRect[0].y)/2); //height = 150
                                sector_middle = set_sector_middle(sectors[0].left,sectors[0].right);
                                set_respawn_points();
                                player_start.x = (mainRect[0].x + mainRect[1].x) / 2;
                                player_start.y = mainRect[1].y - 40;
                                player.set_pos(player_start);
                                break;
                case AI_LEFT:
                                division(mainRect[1].y,mainRect[0].y, mainRect[0].x,(mainRect[1].x - mainRect[0].x)/3); //height = 200
                                sector_middle = set_sector_middle(sectors[sectors_num-1].right,sectors[sectors_num-1].left);
                                set_respawn_points();
                                break;
                case AI_RIGHT:
                                division(mainRect[1].y,mainRect[0].y, mainRect[1].x,(mainRect[1].x - mainRect[0].x) - ((mainRect[1].x - mainRect[0].x)/3)); //height = 600
                                sector_middle = set_sector_middle(sectors[sectors_num-1].right,sectors[sectors_num-1].left);
                                set_respawn_points();
                                break;
                default:
                                division(mainRect[1].x,mainRect[0].x, mainRect[0].y,(mainRect[1].y - mainRect[0].y)/3); //height = 150
                                sector_middle = set_sector_middle(sectors[sectors_num-1].left,sectors[sectors_num-1].right);
                                set_respawn_points();
                                break;
                }
}

void AI :: division(unsigned max_coord,unsigned min_coord, unsigned top, unsigned bottom) {
        sector_lenght = (max_coord - min_coord) / sectors_num;
        unsigned temp_lenght = sector_lenght;
        unsigned temp_lenght2 = 0;
        for(int i = 0; i < sectors_num; i++) {
        sectors[i].left = max_coord - temp_lenght;
        sectors[i].top = top;
        sectors[i].right = max_coord - temp_lenght2;
        sectors[i].bottom = bottom;
        temp_lenght += sector_lenght;
        temp_lenght2 += sector_lenght;
        }
}

void AI :: set_respawn_points(){
unsigned start = 0, end = enemy_num/sectors_num;
unsigned offsetY = (sectors[0].bottom - sectors[0].top)/4;
unsigned offsetX = sector_middle;
        for(int i = 0; i < sectors_num; i++,offsetX -= sector_lenght){
                for(int j = start; j < end; j++, offsetY += (sectors[0].bottom - sectors[0].top)/4){
                respawn_point[j].x = offsetX;
                respawn_point[j].y = sectors[i].bottom - offsetY;
                en_ship[j].set_model_pos(respawn_point[j].x, respawn_point[j].y);
                }
        offsetY = (sectors[0].bottom - sectors[0].top)/4;
        start = end;
        end += 3;
        }
}

unsigned AI :: set_sector_middle(unsigned a, unsigned b) {
return (a + b) / 2;
}

class STATS{
        HPEN Pen;
        HBRUSH Brush;
        RECT rectGraph;
        void DrawShip(HDC hdc);
public:
        STATS();
        void DrawGraphStats(HDC hdc);
};

STATS :: STATS() {
        rectGraph.left = mainRect[0].x/8;
        rectGraph.top =  mainRect[1].y/2;
        rectGraph.right = mainRect[0].x-1;
        rectGraph.bottom = mainRect[1].y - 200;
}

void STATS :: DrawGraphStats(HDC hdc){
        Pen = SelectObject(hdc,CreatePen(PS_SOLID,3,RGB(0,0,100)));
        Brush = SelectObject(hdc,CreateSolidBrush(RGB(0,0,0)));
        Rectangle(hdc,rectGraph.left,rectGraph.top,rectGraph.right,rectGraph.bottom);
        DeleteObject(SelectObject(hdc,Pen));
        DeleteObject(SelectObject(hdc,Brush));
        DrawShip(hdc);
}

void STATS :: DrawShip(HDC hdc) {
        Pen = SelectObject(hdc,CreatePen(PS_SOLID,3,RGB(0,50,0)));

        Brush = SelectObject(hdc,CreateSolidBrush(RGB(0,100,0)));
        Ellipse(hdc,rectGraph.left + 30,rectGraph.top + 30,rectGraph.right - 30,rectGraph.bottom - 30);
        Ellipse(hdc,rectGraph.left + 40,rectGraph.top + 45,rectGraph.right - 40,rectGraph.bottom - 45);
        DeleteObject(SelectObject(hdc,Brush));


        Brush = SelectObject(hdc,CreateSolidBrush(RGB(100,0,0)));
        Rectangle(hdc,rectGraph.left+20,rectGraph.top+85,rectGraph.right-20,rectGraph.bottom - 25);
        Rectangle(hdc,rectGraph.left+10,rectGraph.top+50,rectGraph.right-55,rectGraph.bottom - 55);
        Rectangle(hdc,rectGraph.left+55,rectGraph.top+50,rectGraph.right-10,rectGraph.bottom - 55);
        DeleteObject(SelectObject(hdc,Brush));

        Brush = SelectObject(hdc,CreateSolidBrush(RGB(100,100,0)));
        Rectangle(hdc,rectGraph.left + 40,rectGraph.top + 20,rectGraph.right - 40,rectGraph.top +30);
        Rectangle(hdc,rectGraph.left + 20,rectGraph.top + 40,rectGraph.right - 60,rectGraph.top +50);
        Rectangle(hdc,rectGraph.left + 60,rectGraph.top + 40,rectGraph.right - 20,rectGraph.top +50);
        DeleteObject(SelectObject(hdc,Brush));
        DeleteObject(SelectObject(hdc,Pen));
        }

class STARS{
        int starsNum;
        int starSpeed;
        POINT *mas;
public:
        STARS(unsigned s, unsigned num);
        void starsSet();
        void starsDraw(HDC hdc) const;
};

STARS :: STARS(unsigned s, unsigned num) {
  starSpeed = s;
  starsNum = num;
  mas = new POINT[starsNum];

  srand(time(NULL));
  for(int i = 0; i < starsNum; i++){
        mas[i].x = (rand()%800) + 100;
        mas[i].y = ((600/starsNum)*i)+50;
        }
}

void STARS :: starsSet() {
for(int i = 0; i < starsNum; i++){
        mas[i].y += starSpeed;
        if(mas[i].y > mainRect[1].y){
                mas[i].y = 50;
                mas[i].x = (rand()%800) + 100;
        }
}
}

void STARS :: starsDraw(HDC hdc) const{
for(int i = 0; i < starsNum; i++) SetPixel(hdc,mas[i].x,mas[i].y,RGB(255,255,255));
}

AI control;
STARS star(5,15);
STATS stat;

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
 HWND hWndMain;
 HWND hButton1;
 char szClassName[] = "MainWndClass";
 MSG msg;
 WNDCLASSEX wc;

 wc.cbSize = sizeof(wc);
 wc.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS | CS_OWNDC;
 wc.lpfnWndProc = WndProc;
 wc.cbClsExtra = 0;
 wc.cbWndExtra = 0;
 wc.hInstance = hInstance;
 wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
 wc.hCursor = LoadCursor(NULL, IDC_ARROW);
 wc.hbrBackground = CreatePatternBrush(LoadImage(NULL,"back.bmp",IMAGE_BITMAP,0,0,LR_LOADFROMFILE));
 wc.lpszMenuName = NULL;
 wc.lpszClassName = szClassName;
 wc.hIconSm = LoadIcon(NULL, IDI_WARNING);

 if(!RegisterClassEx(&wc)) {
   MessageBox(NULL, "Cannot register class", "Error", MB_OK);
   return 0;
 }

 hWndMain = CreateWindow(szClassName, "Game. pre-alpha buil.v026", WS_MAXIMIZE | WS_CAPTION | WS_VISIBLE | WS_TABSTOP, CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, (HWND)NULL, (HMENU)NULL, (HINSTANCE) hInstance, NULL);
 //hButton1 = CreateWindow("BUTTON", "exit", WS_CHILD, 0, 0, 100, 20, hWndMain, (HMENU)NULL, (HINSTANCE) hInstance, NULL);
 if(!hWndMain) {
   MessageBox(NULL, "Cannot create main window", "Error", MB_OK);
   return 0;
 }

 ShowWindow(hWndMain, SW_MAXIMIZE);
 //ShowWindow(hButton1, nCmdShow);
 //UpdateWindow(hWndMain);


 while(GetMessage(&msg, NULL, 0, 0)) {
   TranslateMessage(&msg);
   DispatchMessage(&msg);
 }

 return msg.wParam;

}

LRESULT CALLBACK WndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {

HDC hdc;// = GetDC(hwnd);


PAINTSTRUCT ps;
RECT rect;
RECT MyButton;

//
MyButton.left = 5;
MyButton.top = 50;
MyButton.right = 90;
MyButton.bottom = 70;
//

//rect update
RECT updateRect;
updateRect.left = mainRect[0].x;
updateRect.top = mainRect[0].y;
updateRect.right = mainRect[1].x;
updateRect.bottom = mainRect[1].y;
//rect update

//rect color
static HPEN mainRectLine, temp;
static HBRUSH mainRectBack , old;
LOGBRUSH logMRL;
logMRL.lbStyle = BS_SOLID;
logMRL.lbColor = RGB(0,0,100);
//rect color

//ship
char coord[100];
//ship


int hor;
int vert;


switch(uMsg) {
case WM_CREATE:
                srand(time(NULL));
                hdc = GetDC(hwnd);
                control.start_game(hdc,3,AI_TOP);
                SetBkMode(hdc,TRANSPARENT);
                SetTextColor(hdc,RGB(255,255,255));
                SetTimer(hwnd,1,40,NULL);
                SetTimer(hwnd,2,800,NULL);
                break;
case WM_KEYDOWN:
                switch((int) wParam){
                                case VK_SPACE:
                                                KillTimer(hwnd,1);
                                                KillTimer(hwnd,2);
                                                ReleaseDC(hwnd,hdc);
                                                DestroyWindow(hwnd);
                                                PostQuitMessage(0);
                                                break;
                }
                break;
case WM_TIMER :
                switch(wParam){
                        case 2:
                                control.enemy_attack();
                                break;
                        case 1:
                                star.starsSet();
                                control.main_calc();
                                InvalidateRect(hwnd,&updateRect,0);
                                break;
                        }


                break;
case WM_MOUSEMOVE:
                control.player_pos_set(LOWORD(lParam));
                break;
case WM_LBUTTONDOWN:
                control.player_gun_shoot();
                if((LOWORD(lParam) > MyButton.left) && (LOWORD(lParam) < MyButton.right) && (HIWORD(lParam) > MyButton.top) && (HIWORD(lParam) < MyButton.bottom)) DestroyWindow(hwnd);
                break;
case WM_PAINT:
                hdc = BeginPaint(hwnd,&ps);
                GetClientRect(hwnd,&rect);

                //main RECT
                mainRectLine = SelectObject(hdc,ExtCreatePen(PS_GEOMETRIC | PS_SOLID | PS_ENDCAP_SQUARE,3,&logMRL,NULL,NULL));
                mainRectBack = SelectObject(hdc,CreateSolidBrush(RGB(0,0,0)));
                Rectangle(hdc,mainRect[0].x,mainRect[0].y,mainRect[1].x,mainRect[1].y);
                DeleteObject(SelectObject(hdc,mainRectLine));
                //main RECT

                star.starsDraw(hdc);

                //ship navigation
                control.main_draw(hdc);
                //ship navigation

                //bullet
                SelectObject(hdc,old);
                //bullet



                stat.DrawGraphStats(hdc);

                mainRectLine = SelectObject(hdc,ExtCreatePen(PS_GEOMETRIC | PS_SOLID | PS_ENDCAP_SQUARE,3,&logMRL,NULL,NULL));
                mainRectBack = SelectObject(hdc,CreateSolidBrush(RGB(0,0,0)));
                RoundRect(hdc,MyButton.left,MyButton.top,MyButton.right,MyButton.bottom,8,8);
                TextOut(hdc,33,50,"exit",5);
                DeleteObject(SelectObject(hdc,mainRectLine));
                DeleteObject(SelectObject(hdc,mainRectBack));


                //sys inf
                hor = GetDeviceCaps(hdc,HORZRES);
                vert = GetDeviceCaps(hdc,VERTRES);
                sprintf(coord,"sys inf:                            \nsize = %d\nexpl_size = %d\nResolution: %d x %d",bsize,expl_size,hor,vert);
                DrawText(hdc,coord,-1,&updateRect,DT_RIGHT);
                //sys inf
                EndPaint(hwnd,&ps);
                break;
case WM_CLOSE:
                KillTimer(hwnd,1);
                KillTimer(hwnd,2);
                ReleaseDC(hwnd,hdc);
                DestroyWindow(hwnd);
                break;
case WM_DESTROY:
                PostQuitMessage(0);
                break;
default:
                return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

return 0;
}

RECT GetMainRect(){
  RECT mainR;
  mainR.left = mainRect[0].x;
  mainR.top = mainRect[0].y;
  mainR.right = mainRect[1].x;
  mainR.bottom = mainRect[1].y;
}

bool IsPointInRect(RECT rect,POINT pt) {
        if((pt.x > rect.left) && (pt.x < rect.right) && (pt.y > rect.bottom) && (pt.y < rect.top)) return 1;
        else return 0;
}

RECT GetRectFromPoint(RECT r,POINT p,unsigned size){
        r.left = p.x - size/2;
        r.top = p.y - size/2;
        r.right = p.x + size/2;
        r.bottom = p.y + size/2;

        return r;
}


 