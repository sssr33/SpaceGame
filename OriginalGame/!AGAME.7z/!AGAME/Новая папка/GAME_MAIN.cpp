/*BUGS:
        1.����������� ������ ������.
                �������������:
                        1.�������� �������� �� ��������� ���������� ��������� � ���� ��������
                        
        2.�������(��������� ��������� �������� ��������) ������� ������� �� �������� ��������.
                �������������:
                        1.�������� ������, �� ���-�� ������.

*/
#include <windows.h>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <math.h>
#include <list.h>

//������ ��������� �������������� �� �������
#define AI_BOTTOM 0  //not work
#define AI_TOP 1     //work
#define AI_LEFT 2    //not work
#define AI_RIGHT 3   //not work
//������ ��������� �������������� �� �������

//����������� ��������� �����
#define GUN_UP 0     //work
#define GUN_DOWN 1   //work
//����������� ��������� �����

POINT mainRect[2] = {{100,50},{900,650}};
int bsize;

class BULLET {
        POINT start_bullet_pos;
        POINT pos_of_bullet;
        void DrawModel(HDC, POINT) const;
        void DrawSmoke(HDC, POINT, int);
public:
        BULLET(POINT);
        void DrawInPoint(HDC,POINT,unsigned);
        POINT GetPos() const;
};

BULLET :: BULLET(POINT start_pos){
        start_bullet_pos = pos_of_bullet = start_pos;
}

POINT BULLET :: GetPos() const { return pos_of_bullet; }

void BULLET :: DrawInPoint(HDC hdc, POINT pos, unsigned smoke_lenght){
        pos_of_bullet = pos;
        int smoke_pixels = start_bullet_pos.y - pos.y;
        if(smoke_pixels > 0 && (smoke_pixels > smoke_lenght + 1)) smoke_pixels = smoke_lenght;
        else if(smoke_pixels < 0 && (abs(smoke_pixels) > smoke_lenght + 1)) smoke_pixels = 0 - smoke_lenght;

        DrawModel(hdc, pos);
        DrawSmoke(hdc,pos,smoke_pixels);
}

void BULLET :: DrawModel(HDC hdc, POINT pos) const{
        MoveToEx(hdc,pos.x,pos.y,NULL);
        LineTo(hdc,pos.x,pos.y + 3);
}

void BULLET :: DrawSmoke(HDC hdc,POINT pos, int smoke_pixels){
        POINT smoke;
        int smoke_direction = 1;
        float white_to_black = 255;
        float color_change_speed = white_to_black / abs(smoke_pixels);

        if(smoke_pixels < 0) {
                        smoke_pixels = abs(smoke_pixels);
                        smoke_direction = -1;
                        }
        smoke.x = pos.x;
        smoke.y = pos.y + smoke_direction;

        for(unsigned i = 0; i < smoke_pixels; i++) {
                SetPixel(hdc,smoke.x,smoke.y,RGB(white_to_black,white_to_black,white_to_black));
                smoke.y += smoke_direction;
                white_to_black -= color_change_speed;
        }
}

class GUN{
        list<BULLET> bullets;
        HPEN bullet_color;
        HPEN explosion_out;
        HBRUSH explosion_inner;
public:
        GUN();
        ~GUN();
        void shoot(POINT);
        void hit(HDC); //full version coming soon...
        void MoveAllBullets(HDC,unsigned,unsigned,unsigned);
};

GUN :: GUN() {
        bullet_color = CreatePen(PS_SOLID,3,RGB(255,0,0));
        //explosion_out = CreatePen(PS_SOLID,4,RGB(255,56,6));
        //explosion_inner = CreateSolidBrush(RGB(236,0,0));
        POINT void_point;
        bullets.push_front(void_point);
}

GUN :: ~GUN() {
        DeleteObject(bullet_color);
}

void GUN :: shoot(POINT start) {
        bullets.push_front(start);
}

void GUN :: hit(HDC hdc) {
      bsize = bullets.size();
        POINT check_pos;

        list<BULLET> :: iterator p = bullets.begin();

        while(p != bullets.end()) {
                check_pos = p->GetPos();


                if((check_pos.y < 70 || check_pos.y > 550) && bullets.size() > 1) { bullets.erase(p--); }
                p++;
        }
}

void GUN :: MoveAllBullets(HDC hdc,unsigned smoke_lenght,unsigned speed = 25,unsigned bullet_direction = GUN_UP){
        POINT pos_change;

        if(bullets.size()) {
        list<BULLET> :: iterator p = bullets.begin();
        SelectObject(hdc,bullet_color);

        while(p != bullets.end()) {
                pos_change = p->GetPos();

                if(bullet_direction == GUN_UP) pos_change.y -= speed;
                if(bullet_direction == GUN_DOWN) pos_change.y += speed;

                p->DrawInPoint(hdc, pos_change, smoke_lenght);

                p++;
        }
        }
}

class SWITCH {
        bool *mas;
        unsigned size;
public:
        SWITCH(unsigned);
        void SetActive(unsigned);
        bool IsActive(unsigned) const;
};

SWITCH :: SWITCH(unsigned size = 10){
        mas = new bool[size];
}

void SWITCH :: SetActive(unsigned index){
        if(index >= size) return;

        for(unsigned i = 0; i < size; i++){
                if(i == index)mas[i] = 1;
                else mas[i] = 0;
        }
}

bool SWITCH :: IsActive(unsigned index) const{
        if(index >= size) return 0;
        else return mas[index];
}

class ENEMY {
   //     friend class AI;
        int a;
        int b;
        SWITCH direction;
        POINT model[2];
        bool status;
public:
        ENEMY() { a = 20; b = 20; status = 1; direction.SetActive(0); }
        void draw_enemy(HDC hdc);
        void set_model_pos(unsigned x, unsigned y);
        void anim_test(unsigned x, unsigned lim1 ,unsigned lim2);
        POINT get_Xt_Xb_pos() const;
        POINT get_gun_pos();
        bool get_status() const;
};

POINT ENEMY :: get_gun_pos() {
        POINT pos;

        pos.y = model[1].y + 3;
        pos.x = (model[0].x + model[1].x) / 2;

        return pos;
}

bool ENEMY :: get_status() const {
        return status;
}

POINT ENEMY :: get_Xt_Xb_pos() const {
POINT pos;
pos.x = model[0].x;
pos.y = model[1].x;

return pos;
}

void ENEMY :: anim_test(unsigned x, unsigned lim1 ,unsigned lim2){
  //if(x > lim1 && x < lim2){
        if((x > (model[0].x + model[1].x) / 2) && (model[0].x > lim1) && (model[1].x < lim2)){ model[0].x += 2; model[1].x += 2; }
        else if((x < (model[0].x + model[1].x) / 2) && (model[0].x > lim1) && (model[1].x < lim2)) { model[0].x -= 2; model[1].x -= 2; }
        else if((x < (model[0].x + model[1].x) / 2) && (model[0].x > lim1) && (model[1].x <= lim2+6)) { model[0].x -= 2; model[1].x -= 2; }
        else if((x > (model[0].x + model[1].x) / 2) && (model[0].x >= lim1-6) && (model[1].x < lim2)) { model[0].x += 2; model[1].x += 2; }
  /*}
  if(x < lim1 && x > lim2){
        if(direction.IsActive(0) && (model[0].x > lim1) && (model[1].x < lim2)) { model[0].x += 2; model[1].x += 2; }
        else if(direction.IsActive(0) && (model[0].x > lim1) && (model[1].x <= lim2+6)) direction.SetActive(1);
        if(direction.IsActive(1) && (model[0].x > lim1) && (model[1].x < lim2)) { model[0].x -= 2; model[1].x -= 2; }
        else if(direction.IsActive(1) && (model[0].x >= lim1-6) && (model[1].x < lim2)) direction.SetActive(0);
  } */
}

void ENEMY :: set_model_pos(unsigned x, unsigned y) {
        model[0].x = x - a;
        model[0].y = y - b;
        model[1].x = x + a;
        model[1].y = y + b;
}

void ENEMY :: draw_enemy(HDC hdc){
        if(status) {
        Rectangle(hdc,model[0].x,model[0].y,model[1].x,model[1].y);
        SetPixel(hdc,(model[0].x + model[1].x) / 2, (model[0].y + model[1].y) / 2,RGB(255,0,0));
        }
}

class AI{
        unsigned sectors_num;
        unsigned sector_lenght;
        unsigned sector_middle;
        RECT *sectors;
        unsigned mode;
        unsigned enemy_num;
        POINT *respawn_point;
        ENEMY *en_ship;
        GUN en_gun[3];

        unsigned active_guns;

        void division(unsigned max_coord,unsigned min_coord, unsigned top, unsigned bottom);
        void set_respawn_points();
        unsigned set_sector_middle(unsigned a, unsigned b);
public:
        AI(unsigned sect, unsigned m);
        void test(HDC);
        void enemy_control(unsigned posX);
        void enemy_attack_show(HDC);
        void enemy_attack();
};

void AI :: enemy_attack_show(HDC hdc) {
                for(int i = 0; i < active_guns;i ++) {
                en_gun[i].hit(hdc);
                en_gun[i].MoveAllBullets(hdc,150,25,GUN_DOWN);
        }
}

void AI :: enemy_attack() {
int temp = 0;

        for(int i = 0; i < enemy_num; i += 3){
              for(int k = i; k < 3 + i;k++){
                if(en_ship[k].get_status()) { en_gun[temp].shoot(en_ship[k].get_gun_pos()); temp++; break;}
              }
        }
active_guns = temp;
}

void AI :: enemy_control(unsigned posX) {
POINT pos;
pos.x = 300;
pos.y = 100;
unsigned start = 0, end = 3;

        for(int i = 0; i < sectors_num, end <= enemy_num; i++) {
        for(int start = 0; start < end; start++) {
                //pos = en_ship[0].get_Xt_Xb_pos();
                /*if((pos.x > sectors[i].left) && (pos.y < sectors[i].right))*/
                en_ship[start].anim_test(posX,sectors[i].left,sectors[i].right);
        }
        start = end;
        end += 3;
        }
}

AI :: AI(unsigned sect, unsigned m) {
        enemy_num = 9;
        sectors_num = sect;
        en_ship = new ENEMY[enemy_num];
        sectors = new RECT[sectors_num];
        respawn_point = new POINT[enemy_num];
                switch(m) {
                case AI_BOTTOM:

                                division(mainRect[1].x,mainRect[0].x, mainRect[1].y,(mainRect[1].y - mainRect[0].y) - ((mainRect[1].y - mainRect[0].y)/3));//height = 450
                                sector_middle = set_sector_middle(sectors[sectors_num-1].left,sectors[sectors_num-1].right);
                                set_respawn_points();
                                break;
                case AI_TOP:
                                division(mainRect[1].x,mainRect[0].x, mainRect[0].y,(mainRect[1].y - mainRect[0].y)/2); //height = 150
                                sector_middle = set_sector_middle(sectors[0].left,sectors[0].right);
                                set_respawn_points();
                                break;
                case AI_LEFT:
                                division(mainRect[1].y,mainRect[0].y, mainRect[0].x,(mainRect[1].x - mainRect[0].x)/3); //height = 200
                                sector_middle = set_sector_middle(sectors[sectors_num-1].right,sectors[sectors_num-1].left);
                                set_respawn_points();
                                break;
                case AI_RIGHT:
                                division(mainRect[1].y,mainRect[0].y, mainRect[1].x,(mainRect[1].x - mainRect[0].x) - ((mainRect[1].x - mainRect[0].x)/3)); //height = 600
                                sector_middle = set_sector_middle(sectors[sectors_num-1].right,sectors[sectors_num-1].left);
                                set_respawn_points();
                                break;
                default:
                                division(mainRect[1].x,mainRect[0].x, mainRect[0].y,(mainRect[1].y - mainRect[0].y)/3); //height = 150
                                sector_middle = set_sector_middle(sectors[sectors_num-1].left,sectors[sectors_num-1].right);
                                set_respawn_points();
                                break;
                }
}

void AI :: division(unsigned max_coord,unsigned min_coord, unsigned top, unsigned bottom) {
        sector_lenght = (max_coord - min_coord) / sectors_num;
        unsigned temp_lenght = sector_lenght;
        unsigned temp_lenght2 = 0;
        for(int i = 0; i < sectors_num; i++) {
        sectors[i].left = max_coord - temp_lenght;
        sectors[i].top = top;
        sectors[i].right = max_coord - temp_lenght2;
        sectors[i].bottom = bottom;
        temp_lenght += sector_lenght;
        temp_lenght2 += sector_lenght;
        }
}

void AI :: set_respawn_points(){
unsigned start = 0, end = 3;
//unsigned offsetY = 30;
unsigned offsetY = (sectors[0].bottom - sectors[0].top)/4;
unsigned offsetX = sector_middle;
        for(int i = 0; i < sectors_num, end <= enemy_num; i++,offsetX -= sector_lenght){
                for(int j = start; j < end; j++, offsetY += (sectors[0].bottom - sectors[0].top)/4){
                respawn_point[j].x = offsetX;
                respawn_point[j].y = sectors[i].bottom - offsetY;
                en_ship[j].set_model_pos(respawn_point[j].x, respawn_point[j].y);
                }
        offsetY = (sectors[0].bottom - sectors[0].top)/4;
        start = end;
        end += 3;
        }
}

unsigned AI :: set_sector_middle(unsigned a, unsigned b) {
return (a + b) / 2;
}

void AI :: test(HDC hdc) {
        for(int i = 0; i < enemy_num; i++) en_ship[i].draw_enemy(hdc); //SetPixel(hdc,respawn_point[i].x,respawn_point[i].y,RGB(255,0,0));
        for(int i = 0; i < 3; i++){
        MoveToEx(hdc,sectors[i].left,sectors[i].top,NULL);
        LineTo(hdc,sectors[i].left,sectors[i].bottom);
        }
}

class STATS{
        HPEN Pen;
        HBRUSH Brush;
        RECT rectGraph;
        void DrawShip(HDC hdc);
public:
        STATS();
        void DrawGraphStats(HDC hdc);
};

STATS :: STATS() {
        Pen = CreatePen(PS_SOLID,3,RGB(0,0,100));
        Brush = CreateSolidBrush(RGB(0,0,0));
        rectGraph.left = mainRect[0].x/8;
        rectGraph.top =  mainRect[1].y/2;
        rectGraph.right = mainRect[0].x-1;
        rectGraph.bottom = mainRect[1].y - 200;
}

void STATS :: DrawGraphStats(HDC hdc){
        SelectObject(hdc,Pen);
        SelectObject(hdc,Brush);
        Rectangle(hdc,rectGraph.left,rectGraph.top,rectGraph.right,rectGraph.bottom);
        DrawShip(hdc);
        DeleteObject(Pen);
        DeleteObject(Brush);
}

void STATS :: DrawShip(HDC hdc) {
        Pen = CreatePen(PS_SOLID,3,RGB(0,50,0));//100
        Brush = CreateSolidBrush(RGB(0,100,0));
        SelectObject(hdc,Brush);
        SelectObject(hdc,Pen);

        
        Ellipse(hdc,rectGraph.left + 30,rectGraph.top + 30,rectGraph.right - 30,rectGraph.bottom - 30);
        Ellipse(hdc,rectGraph.left + 40,rectGraph.top + 45,rectGraph.right - 40,rectGraph.bottom - 45);

        Brush = CreateSolidBrush(RGB(100,0,0));
        SelectObject(hdc,Brush);
        Rectangle(hdc,rectGraph.left+20,rectGraph.top+85,rectGraph.right-20,rectGraph.bottom - 25);
        Rectangle(hdc,rectGraph.left+10,rectGraph.top+50,rectGraph.right-55,rectGraph.bottom - 55);
        Rectangle(hdc,rectGraph.left+55,rectGraph.top+50,rectGraph.right-10,rectGraph.bottom - 55);

        Brush = CreateSolidBrush(RGB(100,100,0));
        SelectObject(hdc,Brush);
        Rectangle(hdc,rectGraph.left + 40,rectGraph.top + 20,rectGraph.right - 40,rectGraph.top +30);
        Rectangle(hdc,rectGraph.left + 20,rectGraph.top + 40,rectGraph.right - 60,rectGraph.top +50);
        Rectangle(hdc,rectGraph.left + 60,rectGraph.top + 40,rectGraph.right - 20,rectGraph.top +50);
        }

class STARS{
        int starsNum;
        int starSpeed;
        POINT *mas;
public:
        STARS(unsigned s, unsigned num);
        void starsSet();
        void starsDraw(HDC hdc) const;
};

STARS :: STARS(unsigned s, unsigned num) {
  starSpeed = s;
  starsNum = num;
  mas = new POINT[starsNum];

  srand(time(NULL));
  for(int i = 0; i < starsNum; i++){
        mas[i].x = (rand()%800) + 100;
        mas[i].y = ((600/starsNum)*i)+50;
        }
}

void STARS :: starsSet() {
for(int i = 0; i < starsNum; i++){
        mas[i].y += starSpeed;
        if(mas[i].y > mainRect[1].y){
                mas[i].y = 50;
                mas[i].x = (rand()%800) + 100;
        }
}
}

void STARS :: starsDraw(HDC hdc) const{
for(int i = 0; i < starsNum; i++) SetPixel(hdc,mas[i].x,mas[i].y,RGB(255,255,255));
}

STARS star(5,15);
STATS stat;
AI control(3,AI_TOP);
GUN gun_a;

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
 HWND hWndMain;
 HWND hButton1;
 char szClassName[] = "MainWndClass";
 MSG msg;
 WNDCLASSEX wc;

 wc.cbSize = sizeof(wc);
 wc.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS | CS_OWNDC;
 wc.lpfnWndProc = WndProc;
 wc.cbClsExtra = 0;
 wc.cbWndExtra = 0;
 wc.hInstance = hInstance;
 wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
 wc.hCursor = LoadCursor(NULL, IDC_ARROW);
 wc.hbrBackground = CreatePatternBrush(LoadImage(NULL,"back.bmp",IMAGE_BITMAP,0,0,LR_LOADFROMFILE));
 wc.lpszMenuName = NULL;
 wc.lpszClassName = szClassName;
 wc.hIconSm = LoadIcon(NULL, IDI_WARNING);

 if(!RegisterClassEx(&wc)) {
   MessageBox(NULL, "Cannot register class", "Error", MB_OK);
   return 0;
 }

 hWndMain = CreateWindow(szClassName, "Game. pre-alpha buil.v026", WS_MAXIMIZE | WS_CAPTION | WS_VISIBLE | WS_TABSTOP, CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, (HWND)NULL, (HMENU)NULL, (HINSTANCE) hInstance, NULL);
 //hButton1 = CreateWindow("BUTTON", "exit", WS_CHILD, 0, 0, 100, 20, hWndMain, (HMENU)NULL, (HINSTANCE) hInstance, NULL);
 if(!hWndMain) {
   MessageBox(NULL, "Cannot create main window", "Error", MB_OK);
   return 0;
 }

 ShowWindow(hWndMain, SW_MAXIMIZE);
 //ShowWindow(hButton1, nCmdShow);
 //UpdateWindow(hWndMain);


 while(GetMessage(&msg, NULL, 0, 0)) {
   TranslateMessage(&msg);
   DispatchMessage(&msg);
 }

 return msg.wParam;

}

LRESULT CALLBACK WndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {

HDC hdc;
PAINTSTRUCT ps;
RECT rect;
RECT MyButton;

//
MyButton.left = 5;
MyButton.top = 50;
MyButton.right = 90;
MyButton.bottom = 70;
//

//rect update
RECT updateRect;
updateRect.left = mainRect[0].x;
updateRect.top = mainRect[0].y;
updateRect.right = mainRect[1].x;
updateRect.bottom = mainRect[1].y;
//rect update

//rect color
static HPEN mainRectLine, temp;
static HBRUSH mainRectBack , old;
LOGBRUSH logMRL;
logMRL.lbStyle = BS_SOLID;
logMRL.lbColor = RGB(0,0,100);
//rect color

//ship
static POINT ship;
static POINT bullet;
char coord[100];
//ship


switch(uMsg) {
case WM_CREATE:
                srand(time(NULL));
                hdc = GetDC(hwnd);
                SetBkMode(hdc,TRANSPARENT);
                SetTextColor(hdc,RGB(255,255,255));
                SetTimer(hwnd,1,40,NULL);
                SetTimer(hwnd,2,800,NULL);
                mainRectBack = CreateSolidBrush(RGB(0,0,0));
                mainRectLine = ExtCreatePen(PS_GEOMETRIC | PS_SOLID | PS_ENDCAP_SQUARE,3,&logMRL,NULL,NULL);
                temp = CreatePen(PS_SOLID,3,RGB(255,255,255));
                ReleaseDC(hwnd,hdc);
                break;
case WM_KEYDOWN:
                switch((int) wParam){
                                case VK_SPACE:
                                                KillTimer(hwnd,1);
                                                KillTimer(hwnd,2);
                                                DeleteObject(temp);
                                                DeleteObject(mainRectLine);
                                                DeleteObject(mainRectBack);
                                                DestroyWindow(hwnd);
                                                PostQuitMessage(0);
                                                break;
                }
                break;
case WM_TIMER :
                if(wParam == 2) { control.enemy_attack(); }

                        star.starsSet();
                        control.enemy_control(ship.x);
                        if(bullet.y > 70)bullet.y -= 25;//45;

                        hdc = GetDC(hwnd);
                        gun_a.hit(hdc);
                        ReleaseDC(hwnd,hdc);

                        //if(bullet.y < 150 && bullet.y > 50 && bullet.x > eship.x-25 && bullet.x < eship.x+25)  status = 0;
                        InvalidateRect(hwnd,&updateRect,0);
                break;
case WM_MOUSEMOVE:
                ship.x = LOWORD(lParam);
                ship.y = HIWORD(lParam);
                break;
case WM_LBUTTONDOWN:
                bullet.x = ship.x;
                bullet.y = 500;

                gun_a.shoot(bullet);
                
                //hdc = GetDC(hwnd);

                //MoveToEx(hdc,ship.x,500,NULL);
                //AngleArc(hdc,ship.x,490,10,360,360);
                if((LOWORD(lParam) > MyButton.left) && (LOWORD(lParam) < MyButton.right) && (HIWORD(lParam) > MyButton.top) && (HIWORD(lParam) < MyButton.bottom)) DestroyWindow(hwnd);

                //ReleaseDC(hwnd,hdc);
                break;
case WM_PAINT:
                hdc = BeginPaint(hwnd,&ps);
                //SetBkMode(hdc,TRANSPARENT);
                GetClientRect(hwnd,&rect);

                //main RECT
                SelectObject(hdc,mainRectLine);
                old = SelectObject(hdc,mainRectBack);
                Rectangle(hdc,mainRect[0].x,mainRect[0].y,mainRect[1].x,mainRect[1].y);
                //main RECT

                star.starsDraw(hdc);

                //ship navigation
                SelectObject(hdc,temp);
                if(ship.x-25 > mainRect[0].x + 3 && ship.x+25 < mainRect[1].x - 3)Rectangle(hdc,ship.x-25,500,ship.x+25,550);
                else if(ship.x-25 < mainRect[0].x + 3) Rectangle(hdc,100,500,150,550);
                else if(ship.x+25 > mainRect[1].x - 3) Rectangle(hdc,850,500,900,550);
                //ship navigation

                //bullet
                SelectObject(hdc,old);
                //bull.DrawInPoint(hdc,bullet);
                gun_a.MoveAllBullets(hdc, 150);
                control.enemy_attack_show(hdc);
                //SetPixel(hdc,bullet.x,bullet.y,RGB(255,0,0));
                //bullet

                //sys inf
                sprintf(coord,"sys inf:       \nX = %d  Y = %d\nsize = %d",bullet.x,bullet.y,bsize);
                DrawText(hdc,coord,-1,&updateRect,DT_RIGHT);
                //sys inf

                stat.DrawGraphStats(hdc);
                control.test(hdc);

                SelectObject(hdc,mainRectBack);
                SelectObject(hdc,mainRectLine);
                RoundRect(hdc,MyButton.left,MyButton.top,MyButton.right,MyButton.bottom,8,8);
                TextOut(hdc,33,50,"exit",5);

                EndPaint(hwnd,&ps);
                break;
case WM_CLOSE:
                KillTimer(hwnd,1);
                KillTimer(hwnd,2);
                DeleteObject(temp);
                DeleteObject(mainRectLine);
                DeleteObject(mainRectBack);
                DestroyWindow(hwnd);
                break;
case WM_DESTROY:
                PostQuitMessage(0);
                break;
default:
                return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

return 0;
}


 